import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppMaterialModule } from './app-material.module';
import { SharedModule } from './shared/shared.module';
import { SuccessMsgComponent } from './shared/success-msg/success-msg.component';
import { GuestAuthGuard } from './core/guard/guest.auth.guard';
import { MessageComponent } from './shared/message/message.component';
import { PaymentFailedComponent } from './shared/payment-failed/payment-failed.component';
import { ScanAndUpload } from './shared/scan-and-upload/scan-and-upload.component';

const routes: Routes = [
  {
    path: 'test',
    component: ScanAndUpload
  },
  {
    path: 'payment-succeed',
    component: SuccessMsgComponent,
    canActivate: [GuestAuthGuard]
  },
  {
    path: 'payment-failed',
    component: PaymentFailedComponent,
    canActivate: [GuestAuthGuard]
  },
  {
    path: 'resetPassword/:id',
    loadChildren: () =>
    import("./login1/login1.module").then(m => m.NewLoginScreenModule),
    canActivate: [GuestAuthGuard]
  },
  {
    path: 'resetPassword/:id/:type',
    loadChildren: () =>
    import("./login1/login1.module").then(m => m.NewLoginScreenModule),
    canActivate: [GuestAuthGuard]
  },
  {
    path: 'forgotPwd',
    loadChildren: () =>
    import("./login1/login1.module").then(m => m.NewLoginScreenModule),
    canActivate: [GuestAuthGuard]
  },
  {
    path: 'contact-message/:type',
    component: MessageComponent,
    canActivate: [GuestAuthGuard]
  },
  {
    path: "new-login",
    loadChildren: () =>
      import("./login1/login1.module").then(m => m.NewLoginScreenModule),
      canActivate: [GuestAuthGuard]
  },
  {
    path: "new-motor-info",
    loadChildren: () =>
      import("./motorinfo1/motorinfo1.module").then(m => m.NewMotorInfoScreenModule),
      canActivate: [GuestAuthGuard]
  },
  {
    path: "compare-plans",
    loadChildren: () =>
      import("./compare-plans/compare-plans.module").then(m => m.ComparePlansModule),
      canActivate: [GuestAuthGuard]
  },
  {
    path: "quote-summary",
    loadChildren: () =>
      import("./quote-summary/quote-summary.module").then(m => m.QuoteSummaryModule),
      // canActivate: [GuestAuthGuard]
  },
  {
    path: "additional-details",
    loadChildren: () =>
      import("./additional-details/additional-details.module").then(m => m.AdditionalDetailsModule),
      canActivate: [GuestAuthGuard]
  },
  {
    path: "User",
    loadChildren: () =>
      import("./UserManagement/user.module").then(m => m.userModule)
  },
  {
    path: "Customer360",
    loadChildren: () =>
      import("./customer360/customer360.module").then(m => m.Customer360Module)
  },
  {
    path: 'login',
    loadChildren: () =>
      import("./product-login/product-login.module").then(m => m.ProductLoginModule)
  },
  {
    path: "homelogin",
    loadChildren: () =>
      import("./home-login/home-login.module").then(m => m.HomeLoginModule)
  },
  {
    path: "homeplan",
    loadChildren: () =>
      import("./home-plan/home-plan.module").then(m => m.HomePlanModule)
  },
  {
    path: "homequotesummary",
    loadChildren: () =>
      import("./home-quote-summary/home-quote-summary.module").then(m => m.HomeQuoteSummaryModule)
  },
  {
    path: "homeaddtional",
    loadChildren: () =>
      import("./home-additional/home-additional.module").then(m => m.HomeAdditionalModule)
  },
  {
    path: "incomelogin",
    loadChildren: () =>
      import("./income-login/income-login.module").then(m => m.IncomeLoginModule)
  },
  {
    path: "incomeplan",
    loadChildren: () =>
      import("./income-plan/income-plan.module").then(m => m.IncomePlanModule)
  },
  {
    path:'traveladditional',
    loadChildren: () =>
    import("./travel-additional/travel-additional.module").then(m=> m.TravelAdditionalModule)
  },
  {
    path:'travelinfo',
    loadChildren: () =>
    import("./travel-info/travel-info.module").then(m=> m.TravelInfoModule)
  },
  {
    path: "travelplan",
    loadChildren: () =>
      import("./travel-plan/travel-plan.module").then(m => m.TravelPlanModule)
  },
  {
    path: 'travelquotesummary',
    loadChildren: () =>
    import("./travel-quote-summary/travel-quote-summary.module").then(m=> m.TravelQuoteSummaryModule)
  },
  {
    path: "palogin",
    loadChildren: () =>
      import("./palogin/palogin.module").then(m => m.PALoginModule)
  },
  {
    path: 'pa-plan',
    loadChildren: () =>
    import("./pa-plan/pa-plan.module").then(m => m.PAPlanModule)
    },
    {
      path: 'pa-quote',
      loadChildren: () =>
      import("./pa-quote/pa-quote-summary.module").then(m=> m.PAQuoteSummaryModule)
    },
    {
      path: 'pa-additional',
      loadChildren: () => import("./pa-additional/pa-additional.module").then(m => m.PaAdditionalModule)
    },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true,
    scrollPositionRestoration: 'enabled'
  },
  ), AppMaterialModule,
    SharedModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
