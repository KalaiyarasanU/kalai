// angularLib modules
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgSelectModule } from '@ng-select/ng-select';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { DateTimeAdapter, OwlDateTimeModule, OwlNativeDateTimeModule, OWL_DATE_TIME_FORMATS, OWL_DATE_TIME_LOCALE } from 'ng-pick-datetime';
import { MomentDateTimeAdapter, OwlMomentDateTimeModule } from 'ng-pick-datetime-moment';
import { NgxCaptchaModule } from 'ngx-captcha';
import { NgxCurrencyModule } from "ngx-currency";
import { NgxGaugeModule } from 'ngx-gauge';
import { NgxSpinnerModule } from "ngx-spinner";
import { WebcamModule } from 'ngx-webcam';
import { AppMaterialModule } from './app-material.module';
// modules
import { AppRoutingModule } from './app-routing.module';
// components
import { AppComponent, TimeoutDialogComponent } from './app.component';
import { AppHttpInterceptor } from './app.interceptor';
import { CoreModule } from './core/core.module';
import { AuthGuard } from './core/guard/auth.guard';
import { GuestAuthGuard } from './core/guard/guest.auth.guard';
import { AuthService } from './core/services/auth.service';
import { CoreService } from './core/services/core.service';
import { DataService } from './core/services/data.service';
import { DropDownService } from './core/services/dropdown.service';
import { RuntimeConfigService } from './core/services/runtime-config.service';
import { ContentPopupComponent } from './modal/content-popup/content-popup.component';
import { EmailPopupComponent } from './modal/email-popup/email-popup.component';
import { MessagePopupComponent } from './modal/message-popup/message-popup.component';
import { ProductChangePopupComponent } from './modal/product-change/product-change.component';
import { DynamicContentDialog } from './shared/dynamic-content/dynamic-content.component';
import { OtpVerify } from './shared/otp-verify/otp-verify.component';
import { chooseProduct } from './shared/product-selection/product-selection.component';
import { SharedModule } from './shared/shared.module';
import { ShowImage } from './shared/show-image/show-image.component';
import { WebCamComponent } from './shared/web-cam/web-cam.component';







const userIdleConfig = {
  idle: 300,
  timeout: 1,
  ping: 100
};

export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient, './assets/i18n/', '.json');
}

export const MY_CUSTOM_FORMATS = {
  fullPickerInput: 'DD/MM/YYYY',
  parseInput: localStorage.getItem("DatePickerFormat"),
  datePickerInput: localStorage.getItem("DatePickerFormat"),
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY'
};

export const configFactory = (configService: RuntimeConfigService) => {
  return () => configService.loadConfig();
};

@NgModule({
  declarations: [
    AppComponent,
    TimeoutDialogComponent,
    EmailPopupComponent,
    MessagePopupComponent,
    ProductChangePopupComponent,
    ContentPopupComponent,
  ],
  imports: [
    //angularLib
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    NgSelectModule,
    NgxSpinnerModule,
    HttpClientModule,
    NgxCurrencyModule,
    NgxGaugeModule,
    // UserIdleModule.forRoot(userIdleConfig),

    //angularModules
    AppRoutingModule,
    AppMaterialModule,
    SharedModule,
    CoreModule,
    WebcamModule,

    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),

    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    OwlMomentDateTimeModule,
    NgxCaptchaModule,
  ],
  entryComponents: [chooseProduct, EmailPopupComponent, WebCamComponent, TimeoutDialogComponent
    , MessagePopupComponent, ProductChangePopupComponent, ContentPopupComponent,
    DynamicContentDialog, OtpVerify, ShowImage],
  providers: [
    CoreService,
    AuthGuard,
    GuestAuthGuard,
    DropDownService,
    AuthService,
    DataService,
    { provide: HTTP_INTERCEPTORS, useClass: AppHttpInterceptor, multi: true },
    { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
    { provide: DateTimeAdapter, useClass: MomentDateTimeAdapter, deps: [OWL_DATE_TIME_LOCALE] },
    { provide: OWL_DATE_TIME_FORMATS, useValue: MY_CUSTOM_FORMATS },
    {
      provide: APP_INITIALIZER,
      useFactory: configFactory,
      deps: [RuntimeConfigService],
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})

export class AppModule {
}
