export const config = {
    "clientName": "Customer Portal",
    "dateFormat": "dd/MM/yyyy",
    "currencyFormat": ".2-2",
    "idle": 300,
    "timeout": 1,
    "ping": 100
}
