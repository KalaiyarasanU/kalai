import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class DropDownFilterSerivce {
    dropDowns: any = {};
    constructor( ){
    }

    addDropDown(key: string, values: any){
        this.dropDowns[key] = values;
    }

    getDropDown(key: string){
        return this.dropDowns[key];
    }
    public filterSelectBoxValues(arrayList: any, searchText: any, arrayKey = 'label') {
        let regex: any = null;
        if (!arrayList) {
          return;
        }

        let filteredItem: any;
        if (!searchText) {
          filteredItem = arrayList;
          return filteredItem;
        } else {
          searchText = searchText.toLowerCase();
          regex = new RegExp(searchText, "i");
          filteredItem = arrayList.filter(
            (item: any) => item[arrayKey].toLowerCase().match(regex)
          );
        }
        return filteredItem;
      }
  }