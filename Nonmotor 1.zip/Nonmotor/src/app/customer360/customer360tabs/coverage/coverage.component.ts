import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Subscription } from 'rxjs';
import { Customer360Service } from '../../customer360.service';
import { CoreService } from 'src/app/core/services/core.service';
import { NgxSpinnerService } from "ngx-spinner";
import { AppService } from 'src/app/core/services/app.service';
@Component({
  selector: 'app-coverage',
  templateUrl: './coverage.component.html',
  styleUrls: ['./coverage.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CoverageComponent implements OnInit {
  public language: any;
  public selectedCovers = [];
  public isContentLoaded: boolean;

  constructor(private service1: Customer360Service, private coreservice: CoreService,
    private spinner: NgxSpinnerService, private appService: AppService) { }
  policy: any = [];
  coveragesub: Subscription;

  ngOnInit() {
    this.appService._manualLanguageChange.subscribe(value => {
      if (value && this.isContentLoaded) {
        this.init();
      }
    });
    this.coveragesub = this.service1.ongetpolicyno.subscribe(value => {
      if (value.length != 0) {
        this.policy = value.data;
        this.isContentLoaded = true;
        this.selectedCovers = [];
    if (localStorage.getItem('language') === 'ar') {
      this.policy.risks[0].coverages.forEach(coverage => {
        this.selectedCovers.push(coverage['coverageDescAr']);
      });
    } else {
      this.policy.risks[0].coverages.forEach(coverage => {
        this.selectedCovers.push(coverage['coverageDesc']);
      });
    }
      }
    }, err => {
    })
    this.language = localStorage.getItem("language");
  }

  init() {
    this.selectedCovers = [];
    if (localStorage.getItem('language') === 'ar') {
      this.policy.risks[0].coverages.forEach(coverage => {
        this.selectedCovers.push(coverage['coverageDescAr']);
      });
    } else {
      this.policy.risks[0].coverages.forEach(coverage => {
        this.selectedCovers.push(coverage['coverageDesc']);
      });
    }
  }

  ngDoCheck() {
    if (this.language != localStorage.getItem("language")) {
      this.language = localStorage.getItem("language");
    }
  }
}