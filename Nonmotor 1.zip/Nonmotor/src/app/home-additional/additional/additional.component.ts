import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { CoreService } from '../../core/services/core.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDownService } from '../../core/services/dropdown.service';
import { MatDialog } from '@angular/material/dialog';
import { RequestRedirectComponent } from '../../shared/request-redirect/request-redirect.component';
import { DataService } from 'src/app/core/services/data.service';
import swal from 'sweetalert';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';
import { EmailPopupComponent } from '../../modal/email-popup/email-popup.component';
import { MatStepper } from '@angular/material';
import { StepperSelectionEvent } from '@angular/cdk/stepper';

@Component({
  selector: 'app-additional',
  templateUrl: './additional.component.html',
  styleUrls: ['./additional.component.scss']
})
export class AdditionalComponent implements OnInit {
  @ViewChild('stepper', { static: false }) private stepper: MatStepper;
  propertyDetailForm: FormGroup;
  public quoteNo: any;
  public subscription: Subscription;
  public isAttachmentSubmitted: boolean;
  public isAttachmentArea: boolean;
  public notes: any;
  public effDate;
  public mailId: string;
  additionForm: false;
  public isLoggedInUser: boolean;
  public isContentLoaded: boolean;
  public showHeader = false;
  public isOldQuote;
  public activeStepper;
  public goTo = '';
  public isReviseDetails;
  public quoteDetails: any;
  public addMoreDoc: boolean;
  public mandatoryDocuments: any;
  public fileContainer = [];
  public uploadedDocs = [];
  public language: any;
  public invalidFileFormat: any;
  public DocUploadForm: FormGroup;
  options: any = {};
  constructor(private formBuilder: FormBuilder,
    private fb: FormBuilder,
    public runtimeConfigService: RuntimeConfigService,
    private coreService: CoreService,
    private dropdownservice: DropDownService,
    private spinner: NgxSpinnerService,
    private dialog: MatDialog,
    private translate: TranslateService,
    private route: ActivatedRoute,
    private cdr: ChangeDetectorRef,
    private router: Router) {
    this.route.queryParams
      .subscribe(params => {
        this.quoteNo = params['quoteNo'];
      });
  }

  ngOnInit() {
    this.language = localStorage.getItem("language");
    this.init();
    this.loadQuoteDetails();
    this.loadDropDownValues();
  }
  loadQuoteDetails() {
    if (this.quoteNo.startsWith('P')) {
      this.router.navigate(['/User/dashboard']);
      return;
    }

    let url = "quotes/quoteDetailsSummary";
    let params = {
      quoteNumber: this.quoteNo
    }
    this.dropdownservice.getInputs(url, params).subscribe((response) => {

      if (response.data && response.data != null) {
        this.quoteDetails = response.data.quoteSummary;
        this.spinner.hide();
        this.getUploadedDocs();
        this.mailId = this.quoteDetails.userDetails.email;
      }
      else {
        this.spinner.hide();
      }
    });
  }
  loadDropDownValues() {
    this.getDropDownOptions("propType", "PROP_TYPE", this.runtimeConfigService.config.home_owners_insurance);
    this.getDropDownOptions('motor_emirate', 'MOTOR_EMIRATE', "*");
  }

  getDropDownOptions(key: any, optionId: any, productId: any) {
    this.coreService
      .listOptions(optionId, productId)
      .subscribe((response: any) => {
        this.options[key] = response.data;
      });
  }

  init() {
    console.log('calling init')
    if (localStorage.getItem('isLoggedIn') === 'true') {
      this.isLoggedInUser = true;
    } else {
      this.isLoggedInUser = false;
    }
    ;
    this.DocUploadForm = this.fb.group({});
    this.route.queryParams
      .subscribe(params => {
        this.quoteNo = params['quoteNo'];
        this.isReviseDetails = params['reviseDetails'];
        this.isOldQuote = params['retrieveQuote'];
        this.goTo = params['goTo'];
      });
    this.spinner.show();
    if (this.isReviseDetails || this.isOldQuote) {
      if (this.goTo === '2') {
        this.activeStepper = 'two'
      } else {
        this.activeStepper = 'one';
      }
      this.doContinue('1');
      setTimeout(() => {
        this.goForward();
      }, 1000)
    } else {
      this.loadQuoteDetails();
    }
    this.isContentLoaded = true;
    this.language = localStorage.getItem("language");
    this.notes = [
      {
        name: 'File Type & Size',
        updated: 'JPEG/PNG/PDF/TXT & Max 10 MB',
      }
    ];



    this.coreService.getInputsDbsync('findPolicyStartDate', { quoteNumber: this.quoteNo }).subscribe(res => {
      this.effDate = res;
    });

  }
  ngDoCheck() {
    if (this.language != localStorage.getItem("language")) {
      this.language = localStorage.getItem("language");
    }
  }
  goForward() {
    this.loadQuoteDetails();
  }
  doContinue(value) {
    this.showHeader = true;

  }

  validateAllFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFields(control);
      }
    });
  }
  get formCtrls() {
    return this.propertyDetailForm.controls;
  }
  //  get Uploaded List docs
  getUploadedDocs() {
    let params = {
      quotenumber: this.quoteDetails['quoteId']
    }
    this.subscription = this.coreService.getInputs('documentupload/uploadedDocs', params).subscribe((result: any) => {
      this.uploadedDocs = result;
      console.log(result)
      if (result.length === 11) {
        this.addMoreDoc = true;
        let sortedArray: any[] = result.sort((n1, n2) => n1.docId - n2.docId);
        sortedArray.forEach((element, index) => {
          this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
          let fName = element.fileName.split('_0_');
          this.fileContainer.push(
            {
              typeId: element.polDoId,
              id: element.docId,
              controlName: `documentName${index + 1}`,
              value: fName[1] || null
            }
          )
        });
      } else if (result.length === 0 || result.length === 1) {
        this.getDocuments();
      }
      else {
        // first get mandatory docs
        this.getDocuments();
        this.addMoreDoc = false;
        // second get optional docs
        // if (this.uploadedDocs.length > 3)
        // this.addMoreDocuments();

      }
    });
  }

  ngAfterViewInit() {
    if (this.activeStepper === 'second')
      this.stepper.selectedIndex = 1;
    else if (this.goTo === '2') {
      this.isAttachmentArea = true;
      this.stepper.selectedIndex = 1;
    }
    this.cdr.detectChanges();
  }
  // get mandatory docs
  getDocuments() {
    let body = {
      quoteId: this.quoteDetails['quoteId'],
      loadAllDocs: "N"
    }
    this.subscription = this.coreService.postInputs('documentupload/getUploadDocName', {}, body).subscribe((response: any) => {
      if (response) {
        this.fileContainer = [];
        response.forEach((element, index) => {
          let fName, f = [,];
          this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
          if (this.uploadedDocs.length > 0) {
            fName = this.uploadedDocs.filter(ele =>
              ele.docId === element.polDoId.toString()
            );
            if (fName.length > 0) {
              f = fName[0].fileName.split('_0_');
              this.DocUploadForm.get(`documentName${index + 1}`).clearValidators();
              this.DocUploadForm.get(`documentName${index + 1}`).updateValueAndValidity();
            }
          }

          this.fileContainer.push({
            typeId: element.polDoId,
            id: element.displaySeq,
            label: element.polDocDes,
            labelAr: element.polDocDesAr,
            controlName: `documentName${index + 1}`,
            value: f[1] || null,
            message: `${element.polDocDes} is required`
          });
        });
        console.log(this.fileContainer)
      }
    });
  }

  openDialog(docId, i, value, controlName): void {
    if (i === 0) {
      value = 'Vehicle Registration Card';
    }
    let dialogRef = this.dialog.open(RequestRedirectComponent, {
      panelClass: 'my-class',
      direction: localStorage.getItem('language') === 'ar' ? 'rtl' : 'ltr',
      data: { docId: docId, fileName: value, quoteNo: this.quoteDetails['quoteNumber'] }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let fileName = result.fileName.split('_0_');
        this.fileContainer[i].type = 'scan';
        // this.fileContainer[i].value = `${result.docDesc}`;
        this.fileContainer[i].value = fileName[1];

        this.DocUploadForm.value[controlName] = result.docDesc;
        this.DocUploadForm.value[controlName] = result.docDescAr;
        this.DocUploadForm.controls[controlName].setErrors(null);
      }
    })
  }


  clearFile() {
    var r = document.getElementById('fileUpload') as HTMLInputElement
    r.value = null;
  }



  selectFile(event, docId, i, label, labelAr) {
    if (!event.target.value)
      return;
    this.spinner.show();
    let selectedFileName = event.srcElement.files[0].name;
    const formData = new FormData();
    if (event.target.files.length > 1) {
      formData.append('files', event.target.files[1], selectedFileName);
      formData.append('files', event.target.files[0], 'back');
    } else {
      formData.append('files', event.target.files[0], selectedFileName);
    }
    formData.append('doctypeid', docId);
    formData.append('docDesc', label);
    formData.append('docDescAr', labelAr);
    formData.append('quotenumber', this.quoteDetails['quoteNumber']);

    this.subscription = this.coreService.postInputs('documentupload/uploadMultipleFiles', formData, null).subscribe(response => {
      this.spinner.hide();
      let fName = response.fileName.split('_0_')
      this.fileContainer[i].value = fName[1];
    }, err => {
      this.spinner.hide();
      this.translate.get('FileUploadError').subscribe(value => {
        this.invalidFileFormat = value;
      });
      swal('', this.invalidFileFormat, 'error');
      // if (err.error === 'Maximum upload size exceeded') {
      //   swal('', err.error, 'error')
      // } else if (err.error === 'Internal Server Error') {
      //   swal('', 'Please upload jpg,png,pdf files less than 10MB', 'error')
      // } else {
      //   swal('', this.invalidFileFormat, 'error')
      // }
    })

  }

  onStepperSelectionChange(event: StepperSelectionEvent) {
    let stepLabel = event.selectedStep.label
    this.scrollToSectionHook();
  }

  private scrollToSectionHook() {
    const element = document.querySelector('.stepperTop');
    if (element) {
      setTimeout(() => {
        element.scrollIntoView({
          behavior: 'smooth', block: 'start', inline:
            'nearest'
        });
      }, 250);
    }
  }

  // dynamic 
  addMoreDocuments() {
    if (this.addMoreDoc) {
      return;
    }
    let params = {
      quoteId: this.quoteDetails['quoteId'],
      loadAllDocs: 'Y'
    }
    if (this.DocUploadForm.status === 'INVALID') {
      this.translate.get('MandatoryDocuments').subscribe(value => {
        this.mandatoryDocuments = value;
      });
      swal('', this.mandatoryDocuments, 'error');
      return;
    }
    this.addMoreDoc = true;
    this.subscription = this.coreService.postInputs('documentupload/getUploadDocName', {}, params).subscribe((response: any) => {
      if (response) {

        response.forEach((element, index) => {
          let fName, f = [,];
          this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
          if (this.uploadedDocs.length > 0) {
            fName = this.uploadedDocs.filter(ele =>
              ele.docId === element.polDoId.toString()
            );
            if (fName.length > 0) {
              f = fName[0].fileName.split('_0_');
              this.DocUploadForm.get(`documentName${index + 1}`).clearValidators();
              this.DocUploadForm.get(`documentName${index + 1}`).updateValueAndValidity();
            }
          }

          this.fileContainer.push({
            typeId: element.polDoId,
            id: element.displaySeq,
            label: element.polDocDes,
            labelAr: element.polDocDesAr,
            controlName: `documentName${index + 1}`,
            value: f[1] || null,
            message: `${element.polDocDes} is required`
          });
        });
        console.log(this.fileContainer)
      }
    });
    this.subscription = this.coreService.postInputs('documentupload/getUploadDocName', {}, params).subscribe((response: any) => {
      let shallowcopy = this.fileContainer.slice();
      let value = shallowcopy.splice(1);
      const result = response.filter(({ displaySeq }) => !value.some(x => x.id == displaySeq));
      let index = 4;
      result.forEach((element) => {
        let fName, f = [,];
        this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
        if (this.uploadedDocs.length > 3) {
          fName = this.uploadedDocs.filter(ele =>
            ele.docId === element.displaySeq.toString()
          );
          if (fName.length > 0) {
            f = fName[0].fileName.split('_0_');
          }
        }
        this.fileContainer.push(
          {
            typeId: element.polDoId,
            id: element.displaySeq,
            label: element.polDocDes,
            controlName: `documentName${index + 1}`,
            value: f[1]
          }
        )
        index++;
      });
    });
  }


  doNavigate(event) {
    event.preventDefault();
    this.isAttachmentSubmitted = true;
    if (this.DocUploadForm.status != 'INVALID')
      this.router.navigate([`/homequotesummary`], {
        queryParams: {
          quoteNo: this.quoteNo,
          isQuickSummary: false
        }
      });
  }

  downloadDocuments() {
    let url = `quotes/quotePdfreport?quoteNumber=${this.quoteNo}`
    this.subscription = this.coreService.getDownload(url, '').subscribe((response) => {
      if (response) {
        if (window.navigator && window.navigator.msSaveBlob) {
          var newBlob = new Blob([response], { type: response.type })
          window.navigator.msSaveBlob(newBlob);
          return;
        }
        var link = document.createElement("a");
        link.href = URL.createObjectURL(response);
        link.download = `Quote Schedule.pdf`;
        link.click();
      }
    })
  }
  goBackToDashboard() {
    this.router.navigate(['/User/dashboard']);
  }
  sendMail() {
    console.log(this.mailId);
    let dialogRef = this.dialog.open(EmailPopupComponent, {
      direction: localStorage.getItem('language') === 'ar' ? 'rtl' : 'ltr',
      width: '400px',
      data: {
        head: 'printpopup',
        name: 'this.name',
        mailId: this.mailId,
        docNo: this.quoteNo,
        selectedDocs: `MOT_TPL_QT_${this.quoteNo}_0.pdf`,
        transactionType: 'Q'
      },
      autoFocus: false
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  printDocument() {
    this.subscription = this.coreService.mergeDocument(`quotes/quotePdfreport?quoteNumber=${this.quoteNo}`).subscribe((response: any) => {
      var blob = new Blob([response], { type: 'application/pdf' });
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.contentWindow.print();
    }, err => {
    });
  }
}
