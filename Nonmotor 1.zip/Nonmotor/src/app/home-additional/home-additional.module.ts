import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeAdditionalRoutingModule } from './home-additional-routing.module';
import { AdditionalComponent } from './additional/additional.component';
import { SharedModule } from '../shared/shared.module';


import { AppMaterialModule } from '../app-material.module';
import { TranslateModule } from '@ngx-translate/core';
import { OwlDateTimeModule, OwlNativeDateTimeModule, OWL_DATE_TIME_FORMATS } from 'ng-pick-datetime';
import { DateTimeAdapter, OWL_DATE_TIME_LOCALE } from 'ng-pick-datetime';
import { OwlMomentDateTimeModule, MomentDateTimeAdapter } from 'ng-pick-datetime-moment';
import { CoreModule } from '../core/core.module';
export const MY_CUSTOM_FORMATS = {
  fullPickerInput: 'DD/MM/YYYY',
  parseInput: 'DD/MM/YYYY',
  datePickerInput: 'DD/MM/YYYY',
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY'
};


@NgModule({
  declarations: [AdditionalComponent],
  imports: [
    AppMaterialModule, 
    TranslateModule,
    CommonModule,
    HomeAdditionalRoutingModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    OwlMomentDateTimeModule,
    CoreModule, 
    SharedModule,
  ],
  providers: [
    { provide: DateTimeAdapter, useClass: MomentDateTimeAdapter, deps: [OWL_DATE_TIME_LOCALE] },
    { provide: OWL_DATE_TIME_FORMATS, useValue: MY_CUSTOM_FORMATS },
]
})
export class HomeAdditionalModule { }
