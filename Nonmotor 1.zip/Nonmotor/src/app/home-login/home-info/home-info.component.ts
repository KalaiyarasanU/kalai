import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { Observable, Subscription } from 'rxjs';
import { CoreService } from 'src/app/core/services/core.service';
import { DataService } from 'src/app/core/services/data.service';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';
import swal from 'sweetalert';

import { TranslateService } from '@ngx-translate/core';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { DropDownService } from 'src/app/core/services/dropdown.service';
import { DropDownFilterSerivce } from 'src/app/core/services/dropdownfilter.service';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-home-info',
  templateUrl: './home-info.component.html',
  styleUrls: ['./home-info.component.scss']
})
export class HomeInfoComponent implements OnInit {
  language = localStorage.getItem("language");
  public today = new Date();
  public basicUserDetails: any = {};
  public insuredDetail: FormGroup;
  public ownerStatusForm: FormGroup;
  public additionalDetails: FormGroup;
  public contactDetails: FormGroup;
  public currentYear: any;
  public discountStatusYN: any;
  yes: any;
  no: any;
  public options: any = {};
  public isLoggedInUser: boolean;
  public quoteNo = '';
  public quoteDetails = {};
  public productId;
  public quoteNumber = '';
  public isplanSelected = false;
  isContentLoaded: boolean;
  public subscription: Subscription;
  filteredNationality: Observable<string[]>;
  dobMinVDate;
  dobVDate;
  minIssueDate
  public activeStepper;
  @ViewChild('stepper', { static: false }) private stepper: MatStepper;
  public cityFiltered: FormControl = new FormControl();
  public emirateFiltered: FormControl = new FormControl();
  public nationalityFiltered: FormControl = new FormControl();
  data: any = {
    "lob": "HOME",
    "lobId": this.runtimeConfigService.config.lobid,
    "quoteNumber": "",
    "quoteId": "",
    "userId": "GUEST",
    "transactionType": "FQ",
    "productId": this.runtimeConfigService.config.home_owners_insurance,
    "policySource": "CP",
    "ulmTerm": "02",
    "insured": {},

    "homeDetails": {}
  };

  constructor(public router: Router,
    private formBuilder: FormBuilder,
    public runtimeConfigService: RuntimeConfigService,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute,
    private dropdownservice: DropDownService,
    private coreService: CoreService,
    private translate: TranslateService,
    private dataService: DataService,
    private dropDownFilterSerivce: DropDownFilterSerivce) {
    this.route.queryParams
      .subscribe(params => {
        if (params['quoteNo']) {
          this.quoteNumber = params['quoteNo'];
        }
      });
  }
  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') === 'true') {
      this.isLoggedInUser = true;
    } else {
      this.isLoggedInUser = false;
    }
    if (this.isContentLoaded) {
      this.language = localStorage.getItem('language');
    }
    this.init();
    //********* Nationality filter search starts here***********

    this.subscription = this.coreService.listOptions('NATIONALITY', '*').subscribe((response: any) => {
      this.options['nationality'] = response.data;
      this.dropDownFilterSerivce.addDropDown("NATIONALITY_FILTERED", response.data);
    });
    this.nationalityFiltered.valueChanges
      .pipe(debounceTime(100), distinctUntilChanged())
      .subscribe(() => {
        let filteredNationalityList = this.dropDownFilterSerivce.filterSelectBoxValues(
          this.options['nationality'],
          this.nationalityFiltered.value
        );
        this.dropDownFilterSerivce.addDropDown("NATIONALITY_FILTERED", filteredNationalityList);
      });

    // ********EMIRATE FILTER STARTS HERE***********
    this.spinner.show();
    this.subscription = this.coreService.listOptions('MOTOR_EMIRATE', '*').subscribe((response: any) => {
      this.spinner.hide();
      this.options['emirate'] = response.data;
      //  this.dropDownFilterSerivce.addDropDown("EMIRATE_FILTERED",response.data);
    });
    // this.emirateFiltered.valueChanges
    // .pipe(debounceTime(100),distinctUntilChanged())
    // .subscribe(() => {
    //   let filteredEmirateList = this.dropDownFilterSerivce.filterSelectBoxValues(
    //     this.options['emirate'],
    //     this.emirateFiltered.value
    //   );
    //   this.dropDownFilterSerivce.addDropDown("EMIRATE_FILTERED",filteredEmirateList);
    // });
    //EMIRATE FILTER ENDS HERE//

    //***********CITY FILTER STARTS HERE*************
    let params = {
      productId: "*",
      optionType: 'MOTOR_CITY'
    }

    this.subscription = this.coreService.getInputs('options/list', params).subscribe((response) => {
      this.options['city'] = response.data;
      //  this.dropDownFilterSerivce.addDropDown("MOTOR_CITY_FILTERED",response.data);
    });


    // this.cityFiltered.valueChanges
    // .pipe(debounceTime(100), distinctUntilChanged())
    // .subscribe(() => {
    //    let filteredCityList = this.dropDownFilterSerivce.filterSelectBoxValues(
    //     this.options['city'],
    //     this.cityFiltered.value

    //   );
    //   this.dropDownFilterSerivce.addDropDown("MOTOR_CITY_FILTERED",filteredCityList);
    // });
    // CITY FILTER ENDS HERE

    this.patchBasicUserDetails(this.dataService.getUserDetails());
    this.getPortalProductOptions("portalProduct", "PORTAL_PRODUCTS", "*");
    this.getDropDownOptions("gender", "GENDER", "*");
    this.getDropDownOptions('prefix', 'UCD_PREFIX_NAME');
    this.getDropDownOptions('country', 'COUNTRY');
    this.translate.get('Yes').subscribe(value => {
      this.yes = value;
    });
    this.translate.get('No').subscribe(value => {
      this.no = value;
    });
    this.options['discountStatusYN'] = [
      {
        label: this.yes,
        value: 'Y'
      }, {
        label: this.no,
        value: 'N'
      }
    ];

    // revise details
    if (this.quoteNumber) {
      this.getQuoteDetails();
    }
    this.onFormValueChanges();
    this.dobVDate = new Date();
    this.dobVDate.setDate(this.today.getDate() - 1);
    this.dobVDate.setMonth(this.today.getMonth());
    this.dobVDate.setFullYear(this.today.getFullYear() - this.runtimeConfigService.config.DateOfBirthGreaterThan);
    this.dobMinVDate = new Date();
    this.dobMinVDate.setDate(this.today.getDate() - 1);
    this.dobMinVDate.setMonth(this.today.getMonth());
    this.dobMinVDate.setFullYear(this.today.getFullYear() - 75);
  }
  private _filter(value, key): string[] {
    const filterValue = value ? value.toLowerCase() : '';

    let c = this.options[key].filter(option => option['label'].toLowerCase().includes(filterValue));
    return c
  }

  getDropDownOptions(key: string, optionId: string, productId = '*') {
    this.subscription = this.coreService.listOptions(optionId, productId).subscribe((response: any) => {
      this.options[key] = response.data;
    });
  }
  getPortalProductOptions(key: string, optionId: string, productId: string) {
    this.subscription = this.coreService.listOptions(optionId, productId).subscribe((response: any) => {
      this.options[key] = response.data;
      this.getDropDownOptions('countryId', 'WWW_TYPE', response.data[3].value);
      this.getDropDownOptions('stateId', 'LOY_PLAN', response.data[3].value);
    });
  }

  init() {
    this.ownerStatusForm = new FormGroup({
      ownerStatus: new FormControl('', [Validators.required])
    });
    this.insuredDetail = this.formBuilder.group({
      personalId: ['', [Validators.required, Validators.minLength(15)]],
      prefix: ['', [Validators.required]],
      fullName: ['', [Validators.required, Validators.pattern('[a-zA-Z\u0600-\u06FF ]*')]],
      dob: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      nationality: ['', [Validators.required]],
      // email:['',Validators.compose([Validators.required, Validators.email, Validators.pattern(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/)])],
      //  mobileCode:['',[Validators.required]],
      //  mobileNo:['',[Validators.required, Validators.minLength(7),
      // Validators.maxLength(7), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
    });
    this.contactDetails = this.formBuilder.group({
      address1: ['', [Validators.required]],
      address2: ['', []],
      address4: ['', [Validators.required]],
      country: ['12', [Validators.required]],
      city: ['', [Validators.required]],
      postBox: ['', [Validators.required]],
    });
    this.additionalDetails = this.formBuilder.group({
      buildYN: ['', []],
      countryId: ['', []],
      stateId: ['', []],
      cityId: [{ value: '', disabled: false }, []],
    });
  }
  async getQuoteDetails() {
    this.spinner.show();
    let url = "quotes/quoteDetailsSummary";
    let param = {
      quoteNumber: this.quoteNumber
    }
    this.dropdownservice.getInputs(url, param).subscribe((response) => {
      this.spinner.hide();
      this.quoteDetails = response.data.quoteSummary;
      this.disableInsuredControls();
      if (this.quoteDetails) {
        this.productId = this.quoteDetails['productTypeId']
        this.patchQuoteDetails();
      }
    }, err => {
      let errorMsg = err.error.text || err.error.error || err.error;
      swal('', errorMsg, 'error');
    });
  }
  patchQuoteDetails() {
    this.patchBasicUserDetails(this.dataService.getUserDetails());
    this.insuredDetail.patchValue(this.quoteDetails['userDetails']);
    this.insuredDetail.patchValue({
      personalId: this.quoteDetails['userDetails']['personalId'],
      prefix: this.quoteDetails['userDetails']['prefixBL'],
      fullName: this.quoteDetails['userDetails']['fullName'],
      dob: this.quoteDetails['userDetails']['dob'],
      gender: this.quoteDetails['userDetails']['gender'],
      nationality: this.quoteDetails['userDetails']['nationality']
    });
    this.contactDetails.patchValue(this.quoteDetails['userDetails']);
    this.contactDetails.patchValue({
      address1: this.quoteDetails['userDetails']['address1'],
      address2: this.quoteDetails['userDetails']['address2'],
      address4: this.quoteDetails['userDetails']['address4'],
      postBox: this.quoteDetails['userDetails']['postBox'],
      city: this.quoteDetails['userDetails']['city']
    });
    this.additionalDetails.patchValue(this.quoteDetails['homeDetails']);
    this.additionalDetails.patchValue({
      buildYN: this.quoteDetails['homeDetails']['buildYN'],
      countryId: this.quoteDetails['homeDetails']['countryId'],
      stateId: this.quoteDetails['homeDetails']['stateId'],
      cityId: this.quoteDetails['homeDetails']['cityId']
    });
  }
  onFormValueChanges() {
    this.currentYear = moment().format("YYYY-01-01");
    this.insuredDetail.get('dob').statusChanges.subscribe(val => {
      if (val === 'VALID') {
        let dob = this.insuredDetail.get('dob').value;
        let date = moment(dob).add('years', this.runtimeConfigService.config.LicenseIssuedDateGreaterThanDOB)['_d'];
        this.minIssueDate = date.toISOString();
      }
    });
  }
  patchBasicUserDetails(value) {
    if (!(Object.keys(value).length === 0 && value.constructor === Object)) {
      this.basicUserDetails = value;
      if (value.productType === this.runtimeConfigService.config.home_owners_insurance) {
        this.productId = this.runtimeConfigService.config.home_owners_insurance;
        this.basicUserDetails['productTypeName'] = 'Home Owners Insurance';
      } else {
        this.productId = this.runtimeConfigService.config.tenants_compensation;
        this.basicUserDetails['productTypeName'] = 'Home Tenant Insurance';
      }
    }
  }

  goNext(stepper: MatStepper) {
    stepper.next();
  }
  trackByFn(index) {
    return index;
  }
  emiratesChange(value) {
    let params = {
      productId: "*",
      filterByValue: value,
      optionType: 'MOTOR_CITY'
    }
    this.spinner.show();
    this.coreService.getInputs('options/list', params).subscribe((response) => {
      this.spinner.hide();
      this.options['city'] = response.data;
    });

    params = {
      productId: "*",
      filterByValue: this.contactDetails.value.address4,
      optionType: 'LOC_DIVN'
    }
    this.subscription = this.coreService.getInputs('options/list', params).subscribe(res => {
      this.additionalDetails['branchId'] = res.data[0].value;
      this.data['branchId'] = res.data[0].value
    })
  }

  loyalityPlan(event: any) {



    // if(event.value=="001"){
    //   this.show = true;
    // }
    //  else{
    //   this.show = false;
    //  }
  }
  planSelected(event: any) {
    if (event.value) {
      this.isplanSelected = true;
    } else {
      this.isplanSelected = false;
    }
  }
  propertyType(value: string) {
    if (value == 'Owner') {
      this.ownerStatusForm.patchValue({
        ownerStatus: 'O',
      });
    }
    else {
      this.ownerStatusForm.patchValue({
        ownerStatus: 'T',
      });
    }

  }

  goPlans() {
    this.validateAllFormFields(this.contactDetails);
    this.validateAllFormFields(this.insuredDetail);
    this.validateAllFormFields(this.additionalDetails);
    let dob;

    if (this.insuredDetail['value']['dob']['_d']) {
      dob = new Date(this.insuredDetail['value']['dob']);
      dob.setDate(dob.getDate() + 1);
    } else {
      dob = this.insuredDetail['value']['dob'];
    }
    if ((this.insuredDetail.status == "DISABLED" || this.insuredDetail.status === 'VALID') && this.contactDetails.status === 'VALID' && this.additionalDetails.status === 'VALID') {
      this.data.insured = this.insuredDetail.value;
      this.data['insured']['personalId'] = this.insuredDetail.value.personalId;
      this.data['insured']['prefix'] = this.insuredDetail.value.prefix;
      this.data['insured']['fullName'] = this.insuredDetail.value.fullName;
      this.data['insured']['dob'] = dob;
      this.data['insured']['email'] = this.dataService.getUserDetails().email;
      this.data['insured']['gender'] = this.insuredDetail.value.gender;
      this.data['insured']['nationality'] = this.insuredDetail.value.nationality;
      this.data['insured']['mobileCode'] = this.dataService.getUserDetails().mobileCode;
      this.data['insured']['mobileNo'] = this.dataService.getUserDetails().mobileNo;

      this.data['insured']['phoneCode'] = this.dataService.getUserDetails().mobileCode;
      this.data['insured']['phoneNo'] = this.dataService.getUserDetails().mobileNo;
      this.data['insured']['customerType'] = "I";


      //  this.data.contactDetails = this.contactDetails.value;
      this.data['insured']['address1'] = this.contactDetails.value.address1;
      this.data['insured']['address2'] = this.contactDetails.value.address2;
      this.data['insured']['address4'] = this.contactDetails.value.address4;
      this.data['insured']['city'] = this.contactDetails.value.city;
      this.data['insured']['postBox'] = this.contactDetails.value.postBox;
      this.data['insured']['country'] = this.contactDetails.value.country;

      this.data.homeDetails = this.additionalDetails.value;

      this.data['homeDetails']['buildYN'] = this.additionalDetails.value.buildYN;
      this.data['homeDetails']['countryId'] = this.additionalDetails.value.countryId;
      this.data['homeDetails']['stateId'] = this.additionalDetails.value.stateId;
      this.data['homeDetails']['cityId'] = this.additionalDetails.value.cityId;
      this.data['quoteId'] = this.quoteNumber;
      if (this.dataService.getUserDetails().productType == this.runtimeConfigService.config.home_owners_insurance) {
        this.data['productId'] = this.runtimeConfigService.config.home_owners_insurance;
        this.data['homeDetails']['ownerStatus'] = "O";
      }
      else {
        this.data['productId'] = this.runtimeConfigService.config.tenants_compensation;
        this.data['homeDetails']['ownerStatus'] = "T";
      }
      this.spinner.show();
      this.coreService.saveInputs('fetchAllPlansWithRate', this.data, null).subscribe(response => {
        console.log(response);
        localStorage.setItem('isPlanCalculated', 'true');
        let HomePageLoader = '';
        this.dataService.setMotorPageLoaderContent(HomePageLoader);
        this.spinner.hide();
        if (response.status === 'VF') {
          this.router.navigate(['/contact-message', 'br-failed']);
        } else {
          this.dataService.setPlanDetails(response);
          this.router.navigate([`/homeplan`],
            {
              queryParams: {
                quoteNo: response.quoteId
              }
            });
        }
      },
        err => {
          this.spinner.hide();
        });
    }


  }

  get formCtrls() {
    return this.insuredDetail.controls;
  }
  get addressformCtrls() {
    return this.contactDetails.controls;
  }
  get addDetailsFormCtrls() {
    return this.additionalDetails.controls;
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  ngDoCheck() {
    if (this.language != localStorage.getItem("language")) {
      this.language = localStorage.getItem("language");
    }
  }
  goBack() {
    if (this.isLoggedInUser) {
      this.router.navigate(['/User/dashboard'])
    } else {
      if (this.quoteNo) {
        this.router.navigate(['/new-login'], {
          queryParams: { reviseDetails: true, quoteNo: this.quoteNo }
        })
      }
      else {
        this.router.navigate(['/new-login'], {
          queryParams: { reviseDetails: true }
        })
      }
    }
  }

  disableInsuredControls() {
    if (!isNullOrUndefined(this.quoteDetails) && !isNullOrUndefined(this.quoteDetails["planId"])) {
      this.formCtrls.personalId.disable();
      this.formCtrls.prefix.disable();
      this.formCtrls.fullName.disable();
      this.formCtrls.dob.disable();
      this.formCtrls.gender.disable();
      this.formCtrls.nationality.disable();
    }
  }
}