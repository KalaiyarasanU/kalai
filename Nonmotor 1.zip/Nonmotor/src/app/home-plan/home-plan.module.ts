import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomePlanRoutingModule } from './home-plan-routing.module';
import { PlanComponent } from './plan/plan.component';


import { AppMaterialModule } from '../app-material.module';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { CoreModule } from '../core/core.module';




@NgModule({
  declarations: [PlanComponent],
  imports: [
    AppMaterialModule, 
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    CommonModule,
    TranslateModule,
    HomePlanRoutingModule,
    CoreModule
  ]
})
export class HomePlanModule { }
