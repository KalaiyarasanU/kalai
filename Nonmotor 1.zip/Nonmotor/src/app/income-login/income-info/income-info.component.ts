import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-income-info',
  templateUrl: './income-info.component.html',
  styleUrls: ['./income-info.component.scss']
})
export class IncomeInfoComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  goPlans(){
    this.router.navigate([`/pa-plan`]);
  }

}
