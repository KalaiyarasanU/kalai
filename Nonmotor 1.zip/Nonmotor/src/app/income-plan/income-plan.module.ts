import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppMaterialModule } from '../app-material.module';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { IncomePlanRoutingModule } from './income-plan-routing.module';
import { PlanComponent } from './plan/plan.component';






@NgModule({
  declarations: [PlanComponent],
  imports: [
    AppMaterialModule, 
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    CommonModule,
    TranslateModule,
    IncomePlanRoutingModule
  ],
})
export class IncomePlanModule { }
