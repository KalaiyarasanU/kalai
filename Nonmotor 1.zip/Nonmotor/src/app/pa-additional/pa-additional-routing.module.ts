import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaAdditionalComponent } from './additional/additional.component';


const routes: Routes = [ {
  path: '', component: PaAdditionalComponent
},

]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaAdditionalRoutingModule { }
