import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from '../app-material.module';
import { SharedModule } from '../shared/shared.module';

import { PaAdditionalRoutingModule } from './pa-additional-routing.module';
import { PaAdditionalComponent } from './additional/additional.component';


import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { CoreModule } from '../core/core.module';



@NgModule({
  declarations: [PaAdditionalComponent],
  imports: [
    AppMaterialModule, 
    CommonModule,
    PaAdditionalRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TranslateModule,
    SharedModule,
    CoreModule

  ]
})
export class PaAdditionalModule { }
