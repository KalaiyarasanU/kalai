import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TravelQuoteSummaryRoutingModule } from './pa-quote-summary-routing.module';
import { QuoteSummaryComponent } from './quote-summary/quote-summary.component';

import { AppMaterialModule } from '../app-material.module';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { CoreModule } from '../core/core.module';


@NgModule({
  declarations: [QuoteSummaryComponent],
  imports: [
    CommonModule,
    TravelQuoteSummaryRoutingModule,
    AppMaterialModule, 
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TranslateModule,
    CoreModule,

  ],
  exports: [],
})
export class PAQuoteSummaryModule { }
