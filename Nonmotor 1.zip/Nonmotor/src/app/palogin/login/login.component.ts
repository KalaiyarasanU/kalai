import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { CoreService } from '../../core/services/core.service';


@Component({
  selector: 'app-palogin',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  guestToken:any;

  constructor(private dialog: MatDialog,private coreService: CoreService,) { }

  ngOnInit() {
    let value = {
      guestUser: true
    }
     this.coreService.postInputs4('login/signIn', value, {}).subscribe(response => {
      this.guestToken = response.data;
      localStorage.setItem('guesttokenDetails', this.guestToken.token);
      localStorage.setItem('isLoggedIn', 'false');
    });
  }

 
}
