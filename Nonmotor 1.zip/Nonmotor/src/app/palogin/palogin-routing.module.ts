import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PersonalAccidentInfoComponent } from './personal-accident-info/personal-accident-info.component';

const routes: Routes = [ 
{
  path: 'pa-info', component : PersonalAccidentInfoComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PALoginRoutingModule { }
