import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalAccidentInfoComponent } from './personal-accident-info.component';

describe('PersonalAccidentInfoComponent', () => {
  let component: PersonalAccidentInfoComponent;
  let fixture: ComponentFixture<PersonalAccidentInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalAccidentInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalAccidentInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
