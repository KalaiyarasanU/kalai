import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { CoreService } from 'src/app/core/services/core.service';
import { DataService } from 'src/app/core/services/data.service';
import * as moment from 'moment';
import swal from 'sweetalert';
import { TranslateService } from '@ngx-translate/core';
import { DropDownService } from 'src/app/core/services/dropdown.service';
import { Subscription } from 'rxjs';
import { DropDownFilterSerivce } from 'src/app/core/services/dropdownfilter.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-personal-accident-info',
  templateUrl: './personal-accident-info.component.html',
  styleUrls: ['./personal-accident-info.component.scss']
})
export class PersonalAccidentInfoComponent implements OnInit {

  public today = new Date()
  public insuredDetail: FormGroup;
  public additionalDetails: FormGroup;
  public contactDetails: FormGroup;
  public currentYear: any;
  public isLoggedInUser: boolean;
  public options: any = {};
  public quoteDetails = {};
  public productId;
  public cityFiltered: FormControl = new FormControl();
  public emirateFiltered: FormControl = new FormControl();
  public nationalityFiltered: FormControl = new FormControl();
  public relationshipFiltered: FormControl = new FormControl();
  isContentLoaded: boolean;
  dobMinVDate;
  public language: any;

  data: any = {
    'lobId': this.runtimeConfigService.config.lobid,
    'insuredDetails': {},
    'lob': 'PA',
    'raterInputs': {},
    'quoteNumber': '',
    'quoteId': '',
    'contactDetails': {},
    'travelDetails': {},
    'userId': 'GUEST',
    'transactionType': 'FQ',
    'productId': this.runtimeConfigService.config.world_wide_personal_accident,
    'policySource': 'CP',
    'ulmTerm': '02',
  };
  dobVDate;
  minIssueDate
  fetchAllPlansWithRateData: any;
  nationalityOptions: any;
  cityOptions: any;
  genderOptions: any;
  professionOptions: any;
  relationOptions: any;
  public subscription: Subscription;
  codeOptions: any;
  public quoteNo = '';
  riskTypeOptions: any;
  quoteNumber: any;
  basicUserDetails: any;
  constructor(public router: Router,
    private formBuilder: FormBuilder,
    public runtimeConfigService: RuntimeConfigService,
    private spinner: NgxSpinnerService,
    private coreService: CoreService,
    private dropdownservice: DropDownService,
    private translate: TranslateService,
    private dataService: DataService,
    private route: ActivatedRoute,
    private dropDownFilterSerivce: DropDownFilterSerivce) {
    this.route.queryParams
      .subscribe(params => {
        if (params['quoteNo']) {
          this.quoteNumber = params['quoteNo'];
        }
      });
  }
  ngOnInit() {
    if (localStorage.getItem('isLoggedIn') === 'true') {
      this.isLoggedInUser = true;
    } else {
      this.isLoggedInUser = false;
    }
    if (this.isContentLoaded) {
      this.language = localStorage.getItem('language');
    }
    this.init();
    this.getPortalProductOptions("portalProduct", "PORTAL_PRODUCTS", "*");

    //********* Nationality filter search starts here***********

    this.subscription = this.coreService.listOptions('NATIONALITY', '*').subscribe((response: any) => {
      this.options['nationality'] = response.data;
      this.dropDownFilterSerivce.addDropDown("NATIONALITY_FILTERED", response.data);
    });
    this.nationalityFiltered.valueChanges
      .pipe(debounceTime(100), distinctUntilChanged())
      .subscribe(() => {
        let filteredNationalityList = this.dropDownFilterSerivce.filterSelectBoxValues(
          this.options['nationality'],
          this.nationalityFiltered.value
        );
        this.dropDownFilterSerivce.addDropDown("NATIONALITY_FILTERED", filteredNationalityList);
      });

    // ********EMIRATE FILTER STARTS HERE***********
    this.subscription = this.coreService.listOptions('MOTOR_EMIRATE', '*').subscribe((response: any) => {
      this.options['emirate'] = response.data;
      //  this.dropDownFilterSerivce.addDropDown("EMIRATE_FILTERED",response.data);
    });
    // this.emirateFiltered.valueChanges
    // .pipe(debounceTime(100),distinctUntilChanged())
    // .subscribe(() => {
    //   let filteredEmirateList = this.dropDownFilterSerivce.filterSelectBoxValues(
    //     this.options['emirate'],
    //     this.emirateFiltered.value
    //   );
    //   this.dropDownFilterSerivce.addDropDown("EMIRATE_FILTERED",filteredEmirateList);
    // });
    //EMIRATE FILTER ENDS HERE//

    //***********CITY FILTER STARTS HERE*************
    let params = {
      productId: "*",
      optionType: 'MOTOR_CITY'
    }
    this.subscription = this.coreService.getInputs('options/list', params).subscribe((response) => {
      this.options['city'] = response.data;
      //  this.dropDownFilterSerivce.addDropDown("MOTOR_CITY_FILTERED",response.data);
    });

    // this.cityFiltered.valueChanges
    // .pipe(debounceTime(100), distinctUntilChanged())
    // .subscribe(() => {
    //   let filteredCityList = this.dropDownFilterSerivce.filterSelectBoxValues(
    //     this.options['city'],
    //     this.cityFiltered.value
    //   );
    //   this.dropDownFilterSerivce.addDropDown("MOTOR_CITY_FILTERED",filteredCityList);
    // });
    // CITY FILTER ENDS HERE

    // **********RELATIONSHIP FILTER STARTS HERE**************
    // this.subscription = this.coreService.listOptions('RELATION', '*').subscribe((response: any) => {
    //   this.options['relationship'] = response.data;
    //   this.dropDownFilterSerivce.addDropDown("RELATION_FILTERED",response.data);
    // });
    // this.relationshipFiltered.valueChanges
    // .pipe(debounceTime(100),distinctUntilChanged())
    // .subscribe(() => {
    //   let filteredRelationList = this.dropDownFilterSerivce.filterSelectBoxValues(
    //     this.options['relationship'],
    //     this.relationshipFiltered.value
    //   );
    //   this.dropDownFilterSerivce.addDropDown("RELATION_FILTERED",filteredRelationList);
    // });
    // **********RELATIONSHIP FILTER ENDS HERE**************
    this.getdropdowns();
    this.patchBasicUserDetails(this.dataService.getUserDetails());

    // revise details
    if (this.quoteNumber) {
      console.log(this.quoteNumber);
      this.getQuoteDetails();
    }
    this.onFormValueChanges();
    this.dobVDate = new Date();
    this.dobVDate.setDate(this.today.getDate() - 1);
    this.dobVDate.setMonth(this.today.getMonth());
    this.dobVDate.setFullYear(this.today.getFullYear() - this.runtimeConfigService.config.DateOfBirthGreaterThan);
    this.dobMinVDate = new Date();
    this.dobMinVDate.setDate(this.today.getDate() - 1);
    this.dobMinVDate.setMonth(this.today.getMonth());
    this.dobMinVDate.setFullYear(this.today.getFullYear() - 75);

  }
  getPortalProductOptions(key: string, optionId: string, productId: string) {
    this.spinner.show
    this.subscription = this.coreService.listOptions(optionId, productId).subscribe((response: any) => {
      this.spinner.hide
      this.options[key] = response.data;
      this.subscription = this.coreService.listOptions('RELATION', response.data[4].value).subscribe((response: any) => {
        this.options['relationship'] = response.data;
        this.dropDownFilterSerivce.addDropDown("RELATION_FILTERED", response.data);
      });
      this.relationshipFiltered.valueChanges
        .pipe(debounceTime(100), distinctUntilChanged())
        .subscribe(() => {
          let filteredRelationList = this.dropDownFilterSerivce.filterSelectBoxValues(
            this.options['relationship'],
            this.relationshipFiltered.value
          );
          this.dropDownFilterSerivce.addDropDown("RELATION_FILTERED", filteredRelationList);
        });
    }, err => {
      this.spinner.hide();
    });
  }
  init() {
    this.insuredDetail = this.formBuilder.group({
      personalId: ['', [Validators.required, Validators.minLength(15)]],
      prefix: ['', [Validators.required]],
      fullName: ['', [Validators.required, Validators.pattern('[a-zA-Z\u0600-\u06FF ]*')]],
      dob: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      nationality: ['', [Validators.required]],

    });
    this.contactDetails = this.formBuilder.group({
      address1: ['', [Validators.required]],
      address2: ['', []],
      address4: ['', [Validators.required]],
      country: ['12', [Validators.required]],
      city: ['', [Validators.required]],
      postBox: ['', [Validators.required]],
    });
    this.additionalDetails = this.formBuilder.group({
      //  profession: ['', [Validators.required]],
      // riskType: ['', [Validators.required]],
      beneficiaryName: ['', [Validators.required]],
      beneficiaryRelationship: ['', [Validators.required]],
      vatNumber: ['', []],
      mobileCode: ['', []],
      landlineNumber: ['', []],
    });
  }
  ngDoCheck() {
    if (this.language != localStorage.getItem("language")) {
      this.language = localStorage.getItem("language");
    }
  }

  onFormValueChanges() {
    this.currentYear = moment().format("YYYY-01-01");
    this.insuredDetail.get('dob').statusChanges.subscribe(val => {
      if (val === 'VALID') {
        let dob = this.insuredDetail.get('dob').value;
        let date = moment(dob).add('years', this.runtimeConfigService.config.LicenseIssuedDateGreaterThanDOB)['_d'];
        this.minIssueDate = date.toISOString();
      }
    });
  }

  getdropdowns() {
    this.getDropDownOptions('prefix', 'UCD_PREFIX_NAME');
    this.getDropDownOptions('country', 'COUNTRY');
    this.getGender();
  }
  async getQuoteDetails() {
    this.spinner.show();
    let url = "quotes/quoteDetailsSummary";
    let param = {
      quoteNumber: this.quoteNumber
    }
    this.dropdownservice.getInputs(url, param).subscribe((response) => {
      this.spinner.hide();
      this.quoteDetails = response.data.quoteSummary;
      this.disableInsuredControls();
      if (this.quoteDetails) {
        this.productId = this.quoteDetails['productTypeId']
        this.patchQuoteDetails();
      }
    }, err => {
      let errorMsg = err.error.text || err.error.error || err.error;
      swal('', errorMsg, 'error');
    });
  }

  patchQuoteDetails() {
    this.patchBasicUserDetails(this.dataService.getUserDetails());
    this.insuredDetail.patchValue(this.quoteDetails['userDetails']);
    this.insuredDetail.patchValue({
      personalId: this.quoteDetails['userDetails']['personalId'],
      prefix: this.quoteDetails['userDetails']['prefixBL'],
      fullName: this.quoteDetails['userDetails']['fullName'],
      dob: this.quoteDetails['userDetails']['dob'],
      gender: this.quoteDetails['userDetails']['gender'],
      nationality: this.quoteDetails['userDetails']['nationality']
    });
    this.contactDetails.patchValue(this.quoteDetails['userDetails']);
    this.contactDetails.patchValue({
      address1: this.quoteDetails['userDetails']['address1'],
      address2: this.quoteDetails['userDetails']['address2'],
      address4: this.quoteDetails['userDetails']['address4'],
      postBox: this.quoteDetails['userDetails']['postBox'],
      city: this.quoteDetails['userDetails']['city']
    });
    this.additionalDetails.patchValue(this.quoteDetails['travelDetails']);
    this.additionalDetails.patchValue({
      beneficiaryName: this.quoteDetails['travelDetails']['scopeCvr'],
      beneficiaryRelationship: this.quoteDetails['travelDetails']['relation']
    });
  }
  getDropDownOptions(key: string, optionId: string, productId = '*') {
    this.coreService.listOptions(optionId, productId).subscribe((response: any) => {
      this.options[key] = response.data;
    });
  }

  getGender() {
    let params = {
      optionType: "GENDER",
      productId: '*',
      language: 'en'
    }
    this.coreService.getInputs('options/list', params).subscribe(response => {
      this.genderOptions = response.data;
    });
  }
  patchBasicUserDetails(value) {
    if (!(Object.keys(value).length === 0 && value.constructor === Object)) {
      this.basicUserDetails = value;
      if (value.productType === this.runtimeConfigService.config.world_wide_personal_accident) {
        this.basicUserDetails['productTypeName'] = 'World Wide Personal Accident';
      }
    }
  }

  goPlans() {
    debugger;
    this.validateAllFormFields(this.contactDetails);
    this.validateAllFormFields(this.insuredDetail);
    this.validateAllFormFields(this.additionalDetails);
    let dob;

    if (this.insuredDetail['value']['dob']['_d']) {
      dob = new Date(this.insuredDetail['value']['dob']);
      dob.setDate(dob.getDate() + 1);
    } else {
      dob = this.insuredDetail['value']['dob'];
    }

    if ((this.insuredDetail.status == "DISABLED" || this.insuredDetail.status === 'VALID') && this.contactDetails.status === 'VALID' && this.additionalDetails.status === 'VALID') {
      this.data.insured = this.insuredDetail.value;
      this.data['insured']['personalId'] = this.insuredDetail.value.personalId;
      this.data['insured']['prefix'] = this.insuredDetail.value.prefix;
      this.data['insured']['fullName'] = this.insuredDetail.value.fullName;
      this.data['insured']['dob'] = dob;
      this.data['insured']['email'] = this.dataService.getUserDetails().email;
      this.data['insured']['gender'] = this.insuredDetail.value.gender;
      this.data['insured']['nationality'] = this.insuredDetail.value.nationality;
      this.data['insured']['mobileCode'] = this.dataService.getUserDetails().mobileCode;
      this.data['insured']['mobileNo'] = this.dataService.getUserDetails().mobileNo;

      this.data['insured']['phoneCode'] = this.dataService.getUserDetails().mobileCode;
      this.data['insured']['phoneNo'] = this.dataService.getUserDetails().mobileNo;
      this.data['insured']['customerType'] = "I";

      this.data['insured']['address1'] = this.contactDetails.value.address1;
      this.data['insured']['address2'] = this.contactDetails.value.address2;
      this.data['insured']['address4'] = this.contactDetails.value.address4;
      this.data['insured']['city'] = this.contactDetails.value.city;
      this.data['insured']['postBox'] = this.contactDetails.value.postBox;
      this.data['insured']['country'] = this.contactDetails.value.country;
      this.data['quoteId'] = this.quoteNumber;

      this.data.travelDetails = this.additionalDetails.value;

      this.data['travelDetails']['scopeCvr'] = this.additionalDetails.value.beneficiaryName;
      this.data['travelDetails']['relation'] = this.additionalDetails.value.beneficiaryRelationship;
      //  let MotorPageLoader = 'MotorPageLoaderContent';

      //  this.dataService.setMotorPageLoaderContent(MotorPageLoader);
      this.spinner.show();
      this.coreService.saveInputs('fetchAllPlansWithRate', this.data, null).subscribe(response => {
        console.log(response);
        localStorage.setItem('isPlanCalculated', 'true');
        let HomePageLoader = '';
        this.dataService.setMotorPageLoaderContent(HomePageLoader);
        this.spinner.hide();
        if (response.status === 'VF') {
          this.router.navigate(['/contact-message', 'br-failed']);
        } else {
          this.dataService.setPlanDetails(response);
          this.router.navigate([`/pa-plan`],
            {
              queryParams: {
                quoteNo: response.quoteId
              }
            });
        }
      },
        err => {
          this.spinner.hide();
        });
    }
  }

  get formCtrls() {
    return this.insuredDetail.controls;
  }
  get addressformCtrls() {
    return this.contactDetails.controls;
  }
  get addDetailsFormCtrls() {
    return this.additionalDetails.controls;
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }


  emiratesChange(value) {
    let params = {
      productId: "*",
      filterByValue: value,
      optionType: 'MOTOR_CITY'
    }
    this.spinner.show();
    this.coreService.getInputs('options/list', params).subscribe((response) => {
      this.spinner.hide();
      this.options['city'] = response.data;

    });
    params = {
      productId: "*",
      filterByValue: this.contactDetails.value.address4,
      optionType: 'LOC_DIVN'
    }
    this.subscription = this.coreService.getInputs('options/list', params).subscribe(res => {
      this.additionalDetails['branchId'] = res.data[0].value;
      this.data['branchId'] = res.data[0].value
    })
  }

  trackByFn(index) {
    return index;
  }

  goBack() {

    if (this.isLoggedInUser) {
      this.router.navigate(['/User/dashboard'])
    } else {
      if (this.quoteNo) {
        this.router.navigate(['/new-login'], {
          queryParams: { reviseDetails: true, quoteNo: this.quoteNo }
        })
      }
      else {
        this.router.navigate(['/new-login'], {
          queryParams: { reviseDetails: true }
        })
      }
    }
  }

  disableInsuredControls() {
    if (!isNullOrUndefined(this.quoteDetails) && !isNullOrUndefined(this.quoteDetails["planId"])) {
      this.formCtrls.personalId.disable();
      this.formCtrls.prefix.disable();
      this.formCtrls.fullName.disable();
      this.formCtrls.dob.disable();
      this.formCtrls.gender.disable();
      this.formCtrls.nationality.disable();
    }
  }
}
