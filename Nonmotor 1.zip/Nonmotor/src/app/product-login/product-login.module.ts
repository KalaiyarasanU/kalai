import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from '../app-material.module';

import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';

import { CoreModule } from '../core/core.module';
import { NgxMaskModule } from 'ngx-mask';
import { ProductLoginComponent } from './product-login/product-login.component';
import { ProductLoginRoutingModule } from './product-login-routing.module';


@NgModule({
  declarations: [ProductLoginComponent],
  imports: [
    AppMaterialModule, 
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TranslateModule,
    CoreModule,
    ProductLoginRoutingModule,
    NgxMaskModule.forRoot()
  ],
  entryComponents: [],
  providers: []
})

export class ProductLoginModule { }