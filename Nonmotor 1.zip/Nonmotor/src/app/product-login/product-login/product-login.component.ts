import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { DropDownService } from 'src/app/core/services/dropdown.service';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';

@Component({
  selector: 'app-product-login',
  templateUrl: './product-login.component.html',
  styleUrls: ['./product-login.component.scss']
})
export class ProductLoginComponent implements OnInit {
  public defaultLanguage: any;
  public travelEnableYN: string = "";
  public menuButtonsArray: any[] = new Array();
  public productList: any[] = new Array();
  constructor(private router: Router, public runtimeConfigService: RuntimeConfigService,
    private route: ActivatedRoute, private dropdownservice: DropDownService,
    private translate: TranslateService, private http: HttpClient,
    private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.travelEnableYN = this.runtimeConfigService.config.travelEnableYN;
    this.loadProducts();
  }

  loadProducts() {
    let param = {
      lob: ''
    }
    this.spinner.show();
    this.dropdownservice.getInputs('options/product/list', param).subscribe(async (response: any) => {
      if (response.data && response.data != null) {
        this.productList = response.data as any[];
        await this.loadMenus();
        if (this.menuButtonsArray.length == 1) {
          this.routeApp(this.menuButtonsArray[0].routevalue);
        }
        this.spinner.hide();
      } else {
        this.spinner.hide();
      }

    });
  }

  async loadMenus() {
    this.defaultLanguage = this.translate.currentLang;
    this.menuButtonsArray = new Array();
    for (let e of this.productList) {

      let menu = {
        "buttoncaption": '',
        "routevalue": '',
        "divcaption": ''
      }

      if (e.value == this.runtimeConfigService.config.full_insurance || e.value == this.runtimeConfigService.config.third_party_insurance) {
        if (this.menuButtonsArray.filter(d => d.routevalue == 'motor').length <= 0) {
          menu.buttoncaption = 'MOTORINSURANCE';
          menu.divcaption = await this.getCaption(menu.buttoncaption);
          menu.routevalue = 'motor';
        } else {
          continue;
        }
      }

      if (e.value == this.runtimeConfigService.config.home_owners_insurance) {
        if (this.menuButtonsArray.filter(d => d.routevalue == this.runtimeConfigService.config.home_owners_insurance).length <= 0) {
          menu.buttoncaption = 'HOMEOWNERINSURANCE';
          menu.divcaption = await this.getCaption(menu.buttoncaption);
          menu.routevalue = this.runtimeConfigService.config.home_owners_insurance;
        } else {
          continue;
        }
      }

      if (e.value == this.runtimeConfigService.config.tenants_compensation) {
        if (this.menuButtonsArray.filter(d => d.routevalue == this.runtimeConfigService.config.tenants_compensation).length <= 0) {
          menu.buttoncaption = 'HOMETENANTINSURANCE';
          menu.divcaption = await this.getCaption(menu.buttoncaption);
          menu.routevalue = this.runtimeConfigService.config.tenants_compensation;
        } else {
          continue;
        }
      }

      if (e.value == this.runtimeConfigService.config.travel_insurance) {
        if (this.menuButtonsArray.filter(d => d.routevalue == 'travel').length <= 0) {
          menu.buttoncaption = 'TRAVELINSURANCE';
          menu.divcaption = await this.getCaption(menu.buttoncaption);
          menu.routevalue = 'travel';
        } else {
          continue;
        }
      }

      if (e.value == this.runtimeConfigService.config.world_wide_personal_accident) {
        if (this.menuButtonsArray.filter(d => d.routevalue == this.runtimeConfigService.config.world_wide_personal_accident).length <= 0) {
          menu.buttoncaption = 'PERSONALACCIDENT';
          menu.divcaption = await this.getCaption(menu.buttoncaption);
          menu.routevalue = this.runtimeConfigService.config.world_wide_personal_accident;
        } else {
          continue;
        }
      }
      this.menuButtonsArray.push(menu);
    }
  }

  async getCaption(param: any): Promise<any> {
    let value = "";
    let loadJson = this.translate.currentLang === 'en' ? 'ar' : 'en';
    await this.http
      .get<any>('./assets/i18n/' + loadJson + '.json')
      .toPromise()
      .then(config => {
        value = config[param];
      });
    return value;
  }

  routeApp(data: any) {
    this.router.navigate([`/new-login`], { queryParams: { type: data, } });
  }
  checkLanguage() {
    if (this.defaultLanguage !== this.translate.currentLang) {
      this.loadMenus();
    }
    return true;
  }

}
