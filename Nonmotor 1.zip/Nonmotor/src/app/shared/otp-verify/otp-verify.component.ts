import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subscription } from 'rxjs';
import { AppService } from 'src/app/core/services/app.service';
import { CoreService } from 'src/app/core/services/core.service';
import { DataService } from 'src/app/core/services/data.service';
import { DropDownService } from 'src/app/core/services/dropdown.service';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';

@Component({
  selector: 'otpverfy',
  templateUrl: './otp-verify.component.html',
  styles: [`
   .closeicon_css {
    position: relative;
      cursor: pointer;
  }`],

})
export class OtpVerify {

  dialogeDetails: any;
  public loginOtpForm: FormGroup;
  dropdownOptions: any;
  public minutes = 2;
  public seconds = 0;
  public totalMs = 120000;
  public otpExpired: boolean = true;
  public otpGenerated: boolean = false;
  public otpInterval;
  public subscription: Subscription;
  public emailotpverified: boolean = false;
  public mobileotpverified: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<OtpVerify>,
    private coreService: CoreService,
    public appService: AppService,
    private spinner: NgxSpinnerService,
    private dataService: DataService,
    private router: Router,
    private dropdownservice: DropDownService,
    @Inject(MAT_DIALOG_DATA) public data,
    private builder: FormBuilder,
    private runtimeconfig: RuntimeConfigService
  ) { }

  onNoClick(): void {
    let result = {
      "emailotpverified": this.emailotpverified,
      "mobileotpverified": this.mobileotpverified
    }
    this.dialogRef.close(result);
  }

  ngOnInit() {
    this.loginOtpForm = this.builder.group({
      mobileNoOtp: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(6), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      emailotp: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(6), Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
    });

    this.dropdownservice.getInputs("options/product/list", '').subscribe((response: any) => {
      this.dropdownOptions = response.data;
    });

    this.emailotpverified = this.data.emailotpverified;
    this.mobileotpverified = this.data.mobileotpverified;

    if (this.emailotpverified) this.loginOtpCtrls.emailotp.disable();
    if (this.mobileotpverified) this.loginOtpCtrls.mobileNoOtp.disable();

    this.generateOTP();
  }

  public get loginOtpCtrls() {
    return this.loginOtpForm.controls;
  }

  generateOTP() {
    // if (this.infoForm.status === 'INVALID')
    //   return;

    if (this.mobileotpverified && this.emailotpverified) return;

    let params = {
      "mobileNo": "",
      "email": "",
      "differentotp": this.runtimeconfig.config.differentotp
    }

    if (!this.mobileotpverified)
      params.mobileNo = this.data['mobileno'];

    if (!this.emailotpverified)
      params.email = String(this.data['email']).trim().toLowerCase();

    this.spinner.show();
    this.otpGenerated = false;
    this.subscription = this.coreService.postInputs('/generateOtpForMobEmail', undefined, params).subscribe(res => {
      this.spinner.hide();
      this.otpGenerated = res;
      // if (!this.otpGenerated) return;
      if (!res) {
        this.onNoClick();
        return;
      }
      this.otpExpired = false;
      clearInterval(this.otpInterval);
      this.totalMs = 120000;
      this.minutes = 2;
      this.seconds = 0;
      this.showTimer();
    }, err => {
      this.spinner.hide();
    })
  }

  showTimer() {
    this.otpInterval = setInterval(() => {
      if (this.totalMs >= 0) {
        this.minutes = Math.floor((this.totalMs % (1000 * 60 * 60)) / (1000 * 60));
        this.seconds = Math.floor((this.totalMs % (1000 * 60)) / 1000);
      }
      this.totalMs = this.totalMs - 1000;
      if (this.totalMs === 0) {
        this.otpExpired = true;
        this.otpGenerated = false;
      }
    }, 1000)
  }

  verifyOTP(email: boolean) {
    if (email && this.loginOtpForm.controls.emailotp.invalid) {
      return;
    }

    if (!email && this.loginOtpForm.controls.mobileNoOtp.invalid) {
      return;
    }

    let otpvalue = "", mobileoremail = "";

    if (email) {
      otpvalue = this.loginOtpCtrls.emailotp.value;
      mobileoremail = String(this.data.email).trim().toLowerCase();
    } else {
      otpvalue = this.loginOtpCtrls.mobileNoOtp.value
      mobileoremail = this.data.mobileno;
    }

    let params = {
      "mobileNo": mobileoremail,
      "otp": otpvalue
    }

    this.spinner.show();
    this.subscription = this.coreService.getInputs('validateOtp', params).subscribe(res => {
      this.spinner.hide();
      if (res) {
        this.emailotpverified = email ? true : this.emailotpverified;
        this.mobileotpverified = !email ? true : this.mobileotpverified;
      }
      if (this.emailotpverified) this.loginOtpCtrls.emailotp.disable();
      if (this.mobileotpverified) this.loginOtpCtrls.mobileNoOtp.disable();
    }, err => {
      this.spinner.hide();
    })
  }
}