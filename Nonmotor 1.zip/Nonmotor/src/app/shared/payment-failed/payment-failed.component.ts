import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-message',
    templateUrl: './payment-failed.component.html',
    styleUrls: ['./payment-failed.component.scss']
})
export class PaymentFailedComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }
}