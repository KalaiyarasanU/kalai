import { Component, OnInit, Input, Inject, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CoreService } from 'src/app/core/services/core.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppService } from 'src/app/core/services/app.service';
import { Router } from '@angular/router';
import { DataService } from 'src/app/core/services/data.service';
import { DropDownService } from 'src/app/core/services/dropdown.service';
import { isNullOrUndefined } from 'util';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';

@Component({
  selector: 'chooseProduct',
  templateUrl: './product-selection.component.html',
  styles: [`
   .closeicon_css {
    position: relative;
      cursor: pointer;
  }`],

})
export class chooseProduct {

  dialogeDetails: any;
  public quoteForm: FormGroup;
  dropdownOptions: any;
  public radioError: boolean;
  public invalidChassisNo: boolean;

  constructor(
    public dialogRef: MatDialogRef<chooseProduct>,
    private coreService: CoreService,
    public appService: AppService,
    private spinner: NgxSpinnerService,
    private dataService: DataService,
    private router: Router,
    private dropdownservice: DropDownService,
    @Inject(MAT_DIALOG_DATA) public data,
    private builder: FormBuilder,
    private runtimeConfigService: RuntimeConfigService,
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.quoteForm = this.builder.group({
      type: ['', Validators.required]
    });

    this.dropdownservice.getInputs("options/product/list", '').subscribe((response: any) => {
      this.dropdownOptions = response.data;
    });
  }

  getPlans() {
    if (this.quoteForm.status === 'INVALID') {
      return;
    } else {
      this.spinner.show();
      this.coreService.getInputsDbsync('insured/findByUserId', '').subscribe(res => {
        res['productType'] = this.quoteForm.value.type;
        this.dataService.setUserDetails(res);
        // this.getLoginDetails(res);
        this.gotoNextPage(res);
        this.spinner.hide();
      }, err => {
        this.dialogRef.close();
        this.spinner.hide();
      });
    }
  }

  gotoNextPage(res: any) {
    if (res['productType'] == this.runtimeConfigService.config.full_insurance || res['productType'] == this.runtimeConfigService.config.third_party_insurance) {
      this.router.navigate(['/new-motor-info']);
    }
    else if (res['productType'] == this.runtimeConfigService.config.home_owners_insurance || res['productType'] == this.runtimeConfigService.config.tenants_compensation) {
      this.router.navigate(['/homelogin/home-info']);
    }
    else if (res['productType'] == this.runtimeConfigService.config.world_wide_personal_accident) {
      this.router.navigate(['/palogin/pa-info']);
    }
    else if (res['productType'] == this.runtimeConfigService.config.travel_insurance) {
      this.router.navigate(['/travelinfo']);
    }

    this.dialogRef.close();
  }

  getLoginDetails(result: any) {
    this.spinner.show()
    this.coreService.getLoginDetails().subscribe(res => {
      this.spinner.hide()
      if (!isNullOrUndefined(res)) {
        let userDetail = this.dataService.getUserDetails();
        if (!isNullOrUndefined(res["mobileNo"]) && isNullOrUndefined(userDetail.mobileNo))
          userDetail["mobileNo"] = res["mobileNo"];

        if (!isNullOrUndefined(res["email"]) && isNullOrUndefined(userDetail.email))
          userDetail["email"] = res["email"];

        if (!isNullOrUndefined(res["mobileCode"]) && isNullOrUndefined(userDetail.mobileCode))
          userDetail["mobileCode"] = res["mobileCode"];

        this.dataService.setUserDetails(userDetail);
      }
      this.gotoNextPage(result);
    }, err => {
      this.spinner.hide()
    })
  }

  selectOption() {
    this.radioError = false;
  }
}