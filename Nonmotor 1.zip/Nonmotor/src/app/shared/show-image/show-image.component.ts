import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';
import { CoreService } from 'src/app/core/services/core.service';

@Component({
  selector: 'showimage',
  templateUrl: './show-image.component.html',
  styles: [`
   .closeicon_css {
    position: relative;
      cursor: pointer;
  }
  .image {
    width:500px;
    height:500px;
  }
  .image1 {
    width:700px;
    height:400px;
  }
  `],

})
export class ShowImage {
  selectedPlan: any;
  premiumAmount: any;
  imageWidth: any;
  imageHeight: any;
  constructor(
    public dialogRef: MatDialogRef<ShowImage>,
    private coreService: CoreService,
    private spinner: NgxSpinnerService,
    @Inject(MAT_DIALOG_DATA) public data
  ) {

    this.selectedPlan = "Selected Plan : " + data.planName;
    this.premiumAmount = data.premiumAmount;

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.downloadFile();
  }

  downloadFile() {
    this.spinner.show();
    let imageDoc = document.getElementById("myImg");
    imageDoc.style.display = "none";
    let fName = 'COVERAGES_' + `${this.data.productId}_${this.data.planId}` + '.jpg';
    this.coreService.mergeDocument('documentupload/downloadFile?fileName=' + fName).subscribe((response: any) => {
      if (response) {
        let blob = new Blob([response], { type: response.type });
        let reader = new FileReader();
        reader.readAsDataURL(blob);
        let imageWidth: any, imageHeight: any;
        reader.onloadend = function () {
          let image = document.querySelector('img#myImg');
          image["src"] = reader.result;
          setTimeout(() => {
            imageWidth = image["width"];
            imageHeight = image["height"];
          }, 100);
        }

        setTimeout(() => {
          this.imageWidth = imageWidth;
          this.imageHeight = imageHeight;
          imageDoc.style.display = "block";
          this.spinner.hide();
        }, 500);

      } else {
        this.onNoClick();
        this.spinner.hide();
      }

    }, error => {
      console.log(error);
      this.onNoClick();
    });
  }
}