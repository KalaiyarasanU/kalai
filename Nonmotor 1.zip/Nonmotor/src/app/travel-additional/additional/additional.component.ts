import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RuntimeConfigService } from 'src/app/core/services/runtime-config.service';
import { CoreService } from 'src/app/core/services/core.service';
import { DropDownService } from 'src/app/core/services/dropdown.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { MatDialog, MatStepper } from '@angular/material';
import { StepperSelectionEvent } from '@angular/cdk/stepper';
import { Subscription } from 'rxjs';
import swal from 'sweetalert';
import { DynamicContentDialog } from 'src/app/shared/dynamic-content/dynamic-content.component';
import { AppService } from 'src/app/core/services/app.service';
import { DataService } from 'src/app/core/services/data.service';
import { DatePipe } from '@angular/common';
import { DropDownFilterSerivce } from 'src/app/core/services/dropdownfilter.service';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { EmailPopupComponent } from 'src/app/modal/email-popup/email-popup.component';
import { RequestRedirectComponent } from 'src/app/shared/request-redirect/request-redirect.component';


@Component({
  selector: 'app-additional',
  templateUrl: './additional.component.html',
  styleUrls: ['./additional.component.scss'],
  providers: [DatePipe]
})
export class AdditionalComponent implements OnInit {
  public emirateFiltered: FormControl = new FormControl();  
  @ViewChild('stepper', { static: false }) private stepper: MatStepper;
  public today = new Date()
  public plandetail: any = {};
  public isAttachmentSubmitted: boolean;
  public quoteNo: any;
  public isAttachmentArea: boolean;
  public quoteNumber: any;
  public selectedPlan: any;
  public quoteDetails: any;
  public nowTime: any;
  public minTime: any;
  public isAgreedTerm1: boolean;
  public isAgreedTerm2: boolean;
  public isLoggedInUser: boolean;
  public isQuickSummary = 'true';
  public attachments: any;
  public pageHeader: any;
  public isOldQuote;
  public notes: any;
  public isContentLoaded: boolean;
  public activeStepper;
  public goTo = '';
  public isReviseDetails;
  public summaryFor: any;
  public grossPremium;
  public selectedCovers = [];
  public mailId: string;
  public ncdDeclaration: boolean
  public needNcdDeclaration: boolean;
  public isValidQuote = 'true';
  public language: any;
  public subscription: Subscription;
  public effDate;
  public showHeader = false;
  public offersStatus = true;
  public showNCDDisError: boolean;
  public addMoreDoc: boolean;
  public mandatoryDocuments: any;
  public fileContainer = [];
  public uploadedDocs = [];
  public isContentLoadded: boolean;
  public productTypeName = '';
  public additionalDetails : FormGroup;
  public DocUploadForm: FormGroup;
  public options: any = {};
  constructor(private router: Router, private formBuilder: FormBuilder,
    private fb: FormBuilder,
    private coreService: CoreService,
    private route: ActivatedRoute,
    private appService: AppService,
    private spinner: NgxSpinnerService,
    private translate: TranslateService,
    private cdr: ChangeDetectorRef,
    private datePipe: DatePipe,
    private dropdownservice: DropDownService,
    public dialog: MatDialog,
    public runtimeConfigService: RuntimeConfigService,
    private dataService: DataService,
    private dropDownFilterSerivce:DropDownFilterSerivce) {
    this.route.queryParams
      .subscribe(params => {
        this.quoteNo = params['quoteNo'];
        this.isQuickSummary = params['isQuickSummary'];
        this.isValidQuote = params['validQuote'];
        if (this.isValidQuote != 'false') {
          this.isValidQuote = 'true';
        }
      });
    this.translate.get('QuoteSummary').subscribe(value => {
      this.pageHeader = value;
    });
  }

  ngOnInit() {
    this.language = localStorage.getItem("language");
    this.appService._manualLanguageChange.subscribe(value => {
      if (value && this.isContentLoaded) {
        if (this.stepper.selectedIndex != 2) {
          this.language = localStorage.getItem('language');
          this.init();
        }
      }
    })
     // ********EMIRATE FILTER STARTS HERE***********
    //  this.subscription = this.coreService.listOptions('MOTOR_EMIRATE', '*').subscribe((response: any) => {
    //   this.options['emirate'] = response.data;
    //   this.dropDownFilterSerivce.addDropDown("EMIRATE_FILTERED",response.data);
    // });
    // this.emirateFiltered.valueChanges
    // .pipe(debounceTime(100),distinctUntilChanged())
    // .subscribe(() => {
    //   let filteredEmirateList = this.dropDownFilterSerivce.filterSelectBoxValues(
    //     this.options['emirate'],
    //     this.emirateFiltered.value
    //   );
    //   this.dropDownFilterSerivce.addDropDown("EMIRATE_FILTERED",filteredEmirateList);
    // });
    //EMIRATE FILTER ENDS HERE//
     this.subscription = this.coreService.listOptions('MOTOR_EMIRATE', '*').subscribe((response: any) => {
      this.options['emirate'] = response.data;
    });
    this.loadQuoteDetails();
    this.init();
    this.additionalDetails = this.formBuilder.group({
      origin: ['', [Validators.required]],
      destination: ['', [Validators.required]],
      departureDate: ['', [Validators.required]],
      returnDate: ['', [Validators.required]],
      passportNo: ['', [Validators.required]],
    });
    
  }
  loadQuoteDetails() {
    if (this.quoteNo.startsWith('P')) {
      this.router.navigate(['/User/dashboard']);
      return;
    }
    let url = "quotes/quoteDetailsSummary";
    let params = {
      quoteNumber: this.quoteNo
    }
    this.dropdownservice.getInputs(url, params).subscribe((response) => {
      if (response.data && response.data != null) {
        this.quoteDetails = response.data.quoteSummary;
        this.spinner.hide();
        this.mailId = this.quoteDetails.userDetails.email;
      }
      else {
        this.spinner.hide();
      }
      this.getUploadedDocs();
      let emirate:Array<any> = this.options['emirate'];
        let origin = emirate.find(item => item.label === this.quoteDetails.travelDetails['fcity']);
        let destination = emirate.find(item => item.label === this.quoteDetails.travelDetails['tcity']);
          this.additionalDetails.patchValue({
            origin       : origin.value,
            destination  : destination.value,
            departureDate: this.quoteDetails.travelDetails['fmd'],
            returnDate   : this.quoteDetails.travelDetails['tod'],
            passportNo   : this.quoteDetails.travelDetails['passport']
          })
   
     
    });
  }
  getDropDownOptions(key: string, optionId: string, productId = '*'){
    this.subscription = this.coreService.listOptions(optionId, productId).subscribe((response: any) => {
      this.options[key] = response.data;
    });
  }
   //  get Uploaded List docs
   getUploadedDocs() {
    let params = {
      quotenumber: this.quoteDetails['quoteId']
    }
    this.subscription = this.coreService.getInputs('documentupload/uploadedDocs', params).subscribe((result: any) => {
      this.uploadedDocs = result;
      if (result.length === 11) {
        this.addMoreDoc = true;
        let sortedArray: any[] = result.sort((n1, n2) => n1.docId - n2.docId);
        sortedArray.forEach((element, index) => {
          this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
          let fName = element.fileName.split('_0_');
          this.fileContainer.push(
            {
              typeId: element.polDoId,
              id: element.docId,
              controlName: `documentName${index + 1}`,
              value: fName[1] || null
            }
          )
        });
      } else if (result.length === 0 || result.length === 3) {
        this.getDocuments();
      }
      else {
        // first get mandatory docs
        this.getDocuments();
        this.addMoreDoc = false;
        // second get optional docs
        // if (this.uploadedDocs.length > 3)
        // this.addMoreDocuments();

      }
    });
  }
   // dynamic 
   addMoreDocuments() {
    if (this.addMoreDoc) {
      return;
    }
    let params = {
      quoteId: this.quoteDetails['quoteId'],
      loadAllDocs: 'Y'
    }
    if (this.DocUploadForm.status === 'INVALID') {
      this.translate.get('MandatoryDocuments').subscribe(value => {
        this.mandatoryDocuments = value;
      });
      swal('', this.mandatoryDocuments, 'error');
      return;
    }
    this.addMoreDoc = true;
    this.subscription = this.coreService.postInputs('documentupload/getUploadDocName', {}, params).subscribe((response: any) => {
      if (response) {
       
        response.forEach((element, index) => {
          let fName, f = [,];
          this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
          if (this.uploadedDocs.length > 0) {
            fName = this.uploadedDocs.filter(ele =>
              ele.docId === element.polDoId.toString()
            );
            if (fName.length > 0) {
              f = fName[0].fileName.split('_0_');
              this.DocUploadForm.get(`documentName${index + 1}`).clearValidators();
              this.DocUploadForm.get(`documentName${index + 1}`).updateValueAndValidity();
            }
          }

          this.fileContainer.push({
            typeId: element.polDoId,
            id: element.displaySeq,
            label: element.polDocDes,
            labelAr: element.polDocDesAr,
            controlName: `documentName${index + 1}`,
            value: f[1] || null,
            message: `${element.polDocDes} is required`
          });
        });
        console.log(this.fileContainer)
      }
    });
    this.subscription = this.coreService.postInputs('documentupload/getUploadDocName', {}, params).subscribe((response: any) => {
      let shallowcopy = this.fileContainer.slice();
      let value = shallowcopy.splice(1);
      const result = response.filter(({ displaySeq }) => !value.some(x => x.id == displaySeq));
      let index = 4;
      result.forEach((element) => {
        let fName, f = [,];
        this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
        if (this.uploadedDocs.length > 3) {
          fName = this.uploadedDocs.filter(ele =>
            ele.docId === element.displaySeq.toString()
          );
          if (fName.length > 0) {
            f = fName[0].fileName.split('_0_');
          }
        }
        this.fileContainer.push(
          {
            typeId: element.polDoId,
            id: element.displaySeq,
            label: element.polDocDes,
            controlName: `documentName${index + 1}`,
            value: f[1]
          }
        )
        index++;
      });
    });
  }
  // get mandatory docs
  getDocuments() {
    let body = {
        quoteId: this.quoteDetails['quoteId'],
        loadAllDocs: "N"
    }
    this.subscription = this.coreService.postInputs('documentupload/getUploadDocName', {}, body).subscribe((response: any) => {
      if (response) {
        this.fileContainer = [];
          response.forEach((element, index) => {
          let fName, f = [,];
          this.DocUploadForm.addControl(`documentName${index + 1}`, new FormControl('', (element.mandatoryYN && element.mandatoryYN == 'Y' ? Validators.required : [])));
          if (this.uploadedDocs.length > 0) {
            fName = this.uploadedDocs.filter(ele =>
            ele.docId === element.polDoId.toString()
          );
          if (fName.length > 0) {
            f = fName[0].fileName.split('_0_');
            this.DocUploadForm.get(`documentName${index + 1}`).clearValidators();
            this.DocUploadForm.get(`documentName${index + 1}`).updateValueAndValidity();
          }
        }
      this.fileContainer.push({
        typeId: element.polDoId,
        id: element.displaySeq,
        label: element.polDocDes,
        labelAr: element.polDocDesAr,
        controlName: `documentName${index + 1}`,
        value: f[1] || null,
        message: `${element.polDocDes} is required`
      });
   });
  }
  });
  }
  init() {
    console.log('calling init')
    if (localStorage.getItem('isLoggedIn') === 'true') {
      this.isLoggedInUser = true;
    } else {
      this.isLoggedInUser = false;
    }
  ;
    this.DocUploadForm = this.fb.group({});
    this.route.queryParams
      .subscribe(params => {
        this.quoteNo = params['quoteNo'];
        this.isReviseDetails = params['reviseDetails'];
        this.isOldQuote = params['retrieveQuote'];
        this.goTo = params['goTo'];
      });
    this.spinner.show();
    if (this.isReviseDetails || this.isOldQuote) {
      if (this.goTo === '3') {
        this.activeStepper = 'three'
      } else {
        this.activeStepper = 'second';
      }
      this.doContinue('1');
      setTimeout(() => {
        this.goForward();
      }, 1000)
    } else {
      this.loadQuoteDetails();
    }
    this.isContentLoaded = true;
    this.language = localStorage.getItem("language");
    this.notes = [
      {
        name: 'File Type & Size',
        updated: 'JPEG/PNG/PDF/TXT & Max 10 MB',
      }
    ];
  
  
  
    this.coreService.getInputsDbsync('findPolicyStartDate', { quoteNumber: this.quoteNo }).subscribe(res => {
      this.effDate = res;
    });
  
  }
  goForward() {
    this.loadQuoteDetails();
  }
  downloadDocuments() {
    let url = `quotes/quotePdfreport?quoteNumber=${this.quoteNo}`
    this.subscription = this.coreService.getDownload(url, '').subscribe((response) => {
      if (response) {
        if (window.navigator && window.navigator.msSaveBlob) {
          var newBlob = new Blob([response], { type: response.type })
          window.navigator.msSaveBlob(newBlob);
          return;
        }
        var link = document.createElement("a");
        link.href = URL.createObjectURL(response);
        link.download = `Quote Schedule.pdf`;
        link.click();
      }
    })
  }
  ngDoCheck() {
    if (this.language != localStorage.getItem("language")) {
      this.language = localStorage.getItem("language");
      if (this.isQuickSummary == 'false') {
        this.translate.get('SummaryForThe').subscribe(value => {
          this.summaryFor = value;
        });
        this.pageHeader = this.summaryFor + ' ' + this.quoteNo;
      }
      else if (this.isQuickSummary == 'true') {
        this.translate.get('QuoteSummary').subscribe(value => {
          this.pageHeader = value;
        });
      }

    }
  }

  dateConversion(date: any) {
    function formatDate(date) {
      var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

      if (month.length < 2) month = '0' + month;
      if (day.length < 2) day = '0' + day;
      return [year, month, day].join('-');
    }
    return formatDate(date);
  }
  coverageMakeover() {
    this.selectedCovers = [];
    if (localStorage.getItem('language') === 'ar') {
      this.productTypeName = this.quoteDetails.productTypeNameAr;
      this.quoteDetails.risks[0].coverages.forEach(coverage => {
        this.selectedCovers.push(coverage['coverageDescAr']);
      });
    } else {
      this.productTypeName = this.quoteDetails.productTypeName;
      this.quoteDetails.risks[0].coverages.forEach(coverage => {
        this.selectedCovers.push(coverage['coverageDesc']);
      });
    }
  }

  isAgreedStatus(event) {
    if (event.source.id === 'terms1') {
      this.isAgreedTerm1 = event.checked;
    } else if (event.source.id === 'terms2') {
      this.isAgreedTerm2 = event.checked;
    }
  }
  validateAllFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFields(control);
      }
    });
  }
  get formCtrls() {
    return this.additionalDetails.controls;
  }
  addAdditionalDetail(stepper: MatStepper) {
    this.validateAllFields(this.additionalDetails);
    let departureDate;
    let departureDate1;
    departureDate = new Date(this.additionalDetails.value['departureDate']);
    departureDate1 = this.dateConversion(departureDate);
    this.nowTime = this.dateConversion(new Date());
    this.minTime = this.datePipe.transform(new Date(), 'HH:mm');
    if (departureDate1 <= this.nowTime) {
      departureDate1 = departureDate1.concat('T' + this.minTime + ':00.000Z');
    }
    else {
      departureDate1 = departureDate1.concat('T00:00:00.000Z');
    }
    let toDate;
    let toDate1;
    toDate = new Date(this.additionalDetails.value['returnDate']);
    toDate1 = this.dateConversion(toDate);
    this.nowTime = this.dateConversion(new Date());
    this.minTime = this.datePipe.transform(new Date(), 'HH:mm');
    if (toDate1 <= this.nowTime) {
      toDate1 = toDate1.concat('T' + this.minTime + ':00.000Z');
    }
    else {
      toDate1 = toDate1.concat('T00:00:00.000Z');
    }
    let params = {
      quoteNumber:this.quoteNo
    }
    let travellingDetails = {
      fcity : this.additionalDetails.value['origin'],
      tcity : this.additionalDetails.value['destination'],
      fmd   : departureDate1,
      tod: toDate1,
      passport : this.additionalDetails.value['passportNo']
    }
    if (this.additionalDetails.invalid) {
      return;
    }else{
     this.spinner.show();
      this.coreService.postInputs(`travelPaDetails/updateTravelPaDetails`,travellingDetails,params,).subscribe(response => {
      this.spinner.hide();
      stepper.next();
      }, err => {
        this.spinner.hide();
      });
      this.isAttachmentArea = true;
    }
   
  }
  generatePolicy() {
    this.router.navigate([`/payment-succeed`], { queryParams: { quoteNo: this.quoteNo } })
  }
  doContinue(value) {
    this.showHeader = true;
  }
  makePayment() {
    this.spinner.show();
    let body = {
      quoteNo: this.quoteDetails['quoteId']
    }
    if (this.offersStatus)
      body['adYn'] = 'Y';
    else
      body['adYn'] = 'N';
    this.coreService.postInputs2('insured/dnd', '', body).subscribe(res => {
    });
    let PaymentPageLoader = 'PaymentPageLoaderContent';
    this.dataService.setMotorPageLoaderContent(PaymentPageLoader);

    this.coreService.paymentService(this.quoteNo).subscribe(response => {
      let PaymentPageLoader = '';
      this.dataService.setMotorPageLoaderContent(PaymentPageLoader);
      this.spinner.hide();
      if (response) {
        let form = document.createElement("form");
        form.setAttribute('method', "post");
        form.setAttribute('action', response['paymentUrl']);

        let input = document.createElement("input");
        input.type = "text";
        input.name = `TransactionID`;
        input.id = `TransactionID`;
        input.value = `${response['TransactionID']}`;

        form.appendChild(input);

        let btn = document.createElement("button");
        btn.id = `submitBtn`;
        btn.value = `submit`;
        btn.type = `submit`;
        form.appendChild(btn);

        $("body").append(form);
        $("#submitBtn").trigger("click");
      }
    }, err => {
      let PaymentPageLoader = '';
      this.dataService.setMotorPageLoaderContent(PaymentPageLoader);
      this.spinner.hide();
    });
  }
  goBackToDashboard() {
    this.router.navigate(['/User/dashboard']);
  }
  doNavigate(event) {
    event.preventDefault();
      this.isAttachmentSubmitted = true;
     if (this.DocUploadForm.status != 'INVALID')
      this.router.navigate([`/travelquotesummary`], {
        queryParams: {
          quoteNo: this.quoteNo,
          isQuickSummary: false
        }
      });
  }
  openAttachment(value) {
    let fName = `${this.quoteDetails.quoteId}_0_${value}`;
    this.coreService.mergeDocument('documentupload/downloadFile?fileName=' + fName).subscribe((response: any) => {
      if (window.navigator && window.navigator.msSaveBlob) {
        var newBlob = new Blob([response], { type: response.type })
        window.navigator.msSaveBlob(newBlob);
        return;
      }
      var link = document.createElement("a");
      link.href = URL.createObjectURL(response);
      link.download = value;
      link.click();
    });
  }

  sendMail() {
    console.log(this.mailId);
    let dialogRef = this.dialog.open(EmailPopupComponent, {
      direction: localStorage.getItem('language') === 'ar' ? 'rtl' : 'ltr',
      width: '400px',
      data: {
        head: 'printpopup',
        name: 'this.name',
        mailId: this.mailId,
        docNo: this.quoteNo,
        selectedDocs: `MOT_TPL_QT_${this.quoteNo}_0.pdf`,
        transactionType: 'Q'
      },
      autoFocus: false
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }
  printDocument() {
    this.subscription = this.coreService.mergeDocument(`quotes/quotePdfreport?quoteNumber=${this.quoteNo}`).subscribe((response: any) => {
      var blob = new Blob([response], { type: 'application/pdf' });
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      iframe.contentWindow.print();
    }, err => {
    });
  }

  readTermsAndCond(value) {
    let file;
    let windowName;
    console.log(value)
    switch (value) {
      case 1: {
        this.translate.get('TermsAndCondFile').subscribe(value => {
          file = value;
        });
        this.translate.get('TermsAndCondWindowName').subscribe(value => {
          windowName = value;
        });
        break;
      }
      case 2: {
        this.translate.get('PrivacyPolicyFile').subscribe(value => {
          file = `${value + this.quoteDetails.planId + '.pdf'}`;
        });
        this.translate.get('PrivacyPolicyWindowName').subscribe(value => {
          windowName = value;
        });
        break;
      }
      case 3: {
        this.translate.get('RefundPolicyFile').subscribe(value => {
          file = value;
        });
        this.translate.get('RefundPolicyWindowName').subscribe(value => {
          windowName = value;
        });
        break;
      }
    }
    let param = {
      fileName: file
    }
    console.log(param)
    this.spinner.show();
    this.coreService.getDownload('document/downloadPDF', param).subscribe(response => {
      const userAgent = window.navigator.userAgent;
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        var newBlob = new Blob([response], { type: response.type })
        window.navigator.msSaveOrOpenBlob(newBlob);
        this.spinner.hide();
      } else if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) { //Safari & Opera iOS
        var url = window.URL.createObjectURL(response);
        window.location.href = url;
        this.spinner.hide();
      } else {
        let fileUrl = window.URL.createObjectURL(response);
        var newWindow = window.open(fileUrl, '_blank');
        setTimeout(function () {
          newWindow.document.title = windowName;
        }, 3000);
        this.spinner.hide();
      }
    }, err => {
      this.spinner.hide();
    })
  }
  openDialog(docId, i, value, controlName): void {
    if (i === 0) {
      value = 'Vehicle Registration Card';
    }
    let dialogRef = this.dialog.open(RequestRedirectComponent, {
      panelClass: 'my-class',
      direction: localStorage.getItem('language') === 'ar' ? 'rtl' : 'ltr',
      data: { docId: docId, fileName: value, quoteNo: this.quoteDetails['quoteNumber'] }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        let fileName = result.fileName.split('_0_');
        this.fileContainer[i].type = 'scan';
        // this.fileContainer[i].value = `${result.docDesc}`;
        this.fileContainer[i].value = fileName[1];

        this.DocUploadForm.value[controlName] = result.docDesc;
        this.DocUploadForm.controls[controlName].setErrors(null);
      }
    })
  }

  readNCDDeclaration() {
    const dialogRef = this.dialog.open(DynamicContentDialog, {
      width: '60%',
      direction: localStorage.getItem('language') === 'ar' ? 'rtl' : 'ltr'
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }

  private scrollToSectionHook() {
    const element = document.querySelector('.stepperTop');
    if (element) {
      setTimeout(() => {
        element.scrollIntoView({
          behavior: 'smooth', block: 'start', inline:
            'nearest'
        });
      }, 250);
    }
  }
  ngAfterViewInit() {
    if (this.activeStepper === 'second')
      this.stepper.selectedIndex = 1;
    else if (this.goTo === '3') {
      this.isAttachmentArea = true;
      this.stepper.selectedIndex = 2;
    }
    this.cdr.detectChanges();
  }
  clearFile() {
    var r = document.getElementById('fileUpload') as HTMLInputElement
    r.value = null;
  }

  goBack(stepper: MatStepper) {
    stepper.previous();
    this.isAttachmentArea = false;
  }
  onStepperSelectionChange(event: StepperSelectionEvent) {
    let stepLabel = event.selectedStep.label
    this.scrollToSectionHook();
  }
  
selectFile(event, docId, i, label,labelAr) {
  if (!event.target.value)
    return;
  this.spinner.show();
  let selectedFileName = event.srcElement.files[0].name;
  const formData = new FormData();
  if (event.target.files.length > 1) {
    formData.append('files', event.target.files[1], selectedFileName);
    formData.append('files', event.target.files[0], 'back');
  } else {
    formData.append('files', event.target.files[0], selectedFileName);
  }
  formData.append('doctypeid', docId);
  formData.append('docDesc', label);
  formData.append('docDescAr', labelAr);
  formData.append('quotenumber', this.quoteDetails['quoteNumber']);
 
  this.subscription = this.coreService.postInputs('documentupload/uploadMultipleFiles', formData, null).subscribe(response => {
    this.spinner.hide();
    let fName = response.fileName.split('_0_')
    this.fileContainer[i].value = fName[1];
  }, err => {
    this.spinner.hide();
    this.translate.get('FileUploadError').subscribe(value => {
   //   this.invalidFileFormat = value;
    });
   // swal('', this.invalidFileFormat, 'error');
    // if (err.error === 'Maximum upload size exceeded') {
    //   swal('', err.error, 'error')
    // } else if (err.error === 'Internal Server Error') {
    //   swal('', 'Please upload jpg,png,pdf files less than 10MB', 'error')
    // } else {
    //   swal('', this.invalidFileFormat, 'error')
    // }
  })

}


}
