import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppMaterialModule } from '../app-material.module';

import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';

import { OwlDateTimeModule, OwlNativeDateTimeModule, OWL_DATE_TIME_FORMATS } from 'ng-pick-datetime';
import { DateTimeAdapter, OWL_DATE_TIME_LOCALE } from 'ng-pick-datetime';
import { OwlMomentDateTimeModule, MomentDateTimeAdapter } from 'ng-pick-datetime-moment';
import { TravelInfoRoutingModule } from './travel-info-routing.module';

import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { TravelInfoComponent } from './travel-info/travel-info.component';
import { CoreModule } from '../core/core.module';
import { NgxMaskModule } from 'ngx-mask';
export const MY_CUSTOM_FORMATS = {
  fullPickerInput: 'DD/MM/YYYY',
  parseInput: 'DD/MM/YYYY',
  datePickerInput: 'DD/MM/YYYY',
  timePickerInput: 'LT',
  monthYearLabel: 'MMM YYYY',
  dateA11yLabel: 'LL',
  monthYearA11yLabel: 'MMMM YYYY'
};

@NgModule({
  declarations: [TravelInfoComponent],
  imports: [
    AppMaterialModule, 
    CommonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    TranslateModule,
    TravelInfoRoutingModule,
    CoreModule,
    NgxMaskModule.forRoot(),
    OwlDateTimeModule,
    NgxMatSelectSearchModule,
    OwlNativeDateTimeModule,
    OwlMomentDateTimeModule,
  ],
  providers: [
    { provide: DateTimeAdapter, useClass: MomentDateTimeAdapter, deps: [OWL_DATE_TIME_LOCALE] },
    { provide: OWL_DATE_TIME_FORMATS, useValue: MY_CUSTOM_FORMATS },
]
})
export class TravelInfoModule { }
