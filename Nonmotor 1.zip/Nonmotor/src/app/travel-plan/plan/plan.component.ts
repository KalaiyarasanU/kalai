import { Component, OnInit, ViewChild, ChangeDetectorRef } from "@angular/core";
import { Router, ActivatedRoute } from '@angular/router';
import { AppService } from '../../core/services/app.service';
import { CoreService } from '../../core/services/core.service';
import { NgxSpinnerService } from 'ngx-spinner';
import swal from 'sweetalert';
import { TranslateService } from '@ngx-translate/core';
import { DataService } from '../../core/services/data.service';
import { DropDownService } from "src/app/core/services/dropdown.service";
import { RuntimeConfigService } from "src/app/core/services/runtime-config.service";
import { MatDialog } from "@angular/material";
import { ShowImage } from "src/app/shared/show-image/show-image.component";

export interface KeyValue<K, V> {
  key: K;
  value: V;
}

@Component({
  selector: 'app-plan',
  templateUrl: './plan.component.html',
  styleUrls: ['./plan.component.scss']
})
export class PlanComponent implements OnInit {

  public mandatoryCovers = {};
  public optionalCovers = {};
  public isPlanAvailable: boolean;
  public isPlanSelected: boolean;
  public planOb = {};
  data: any = {};
  public selectedPlan = {};
  public selectedPlanAmount = '0';
  public reviseDetails = 'false';
  public discounts: any = {};
  public promoDiscounts: any = {};
  public loadings: any = {};
  public charges: any = {};
  public quoteDetails = {};
  public excess: any = {};
  public VatPercentage = '';
  public language: any;
  public quoteNo: any;
  showPromoDiscount = false;
  public discountCode = null;
  selectAlert: any;
  ratingError: any;
  demo1TabIndex;
  disableDisctFld;
  panelOpenState = false;
  @ViewChild('tabGroup', {
    static: false
  }) tabGroup;
  public isContentLoaded: boolean;
  constructor(private router: Router,
    private coreService: CoreService,
    private route: ActivatedRoute,
    private appService: AppService,
    private dropdownservice: DropDownService,
    private spinner: NgxSpinnerService,
    private translate: TranslateService,
    private dataService: DataService,
    private runtimeConfigService: RuntimeConfigService,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog) {
    this.route.queryParams
      .subscribe(params => {
        this.quoteNo = params['quoteNo'];
        if (params['reviseDetails']) {
          this.reviseDetails = params['reviseDetails'];
        }
      });
  }

  originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
    return 0;
  }

  ngOnInit() {
    this.planOb = this.dataService.getPlanDetails();
    this.appService._manualLanguageChange.subscribe(value => {
      if (value && this.isContentLoaded) {
        this.language = localStorage.getItem('language');
        this.loadCovers();
      }
    });
    if (this.planOb) {
      this.loadVATandPremium();
      this.loadCovers();
      this.isContentLoaded = true;
      this.initLoading();
      this.loadExcess();
      this.isPlanAvailable = true;
    } else {
      this.isPlanAvailable = false;
    }
    // if(!this.planOb){
    //   let url = "quotes/quoteDetailsSummary";
    //   let params = {
    //     quoteNumber: this.quoteNo
    //   }
    //   this.dropdownservice.getInputs(url, params).subscribe((response) => {
    //   this.quoteDetails = response.data.quoteSummary;
    //   this.data  = {
    //     "lob":"TRAVEL",
    //     "lobId":"3",
    //     "userId":"GUEST",
    //     "transactionType":"FQ",
    //     "productId":"8108",
    //     "policySource":"CP",
    //     "ulmTerm":"02",
    //     "quoteNumber": "",
    //     "insured":{},
    //     "travelDetails": {}
    //   };
    //   this.data['insured']['personalId'] = this.quoteDetails['userDetails']['personalId'];
    //   this.data['insured']['prefix'] = this.quoteDetails['userDetails']['prefix'];
    //   this.data['insured']['fullName'] = this.quoteDetails['userDetails']['fullName'];
    //   this.data['insured']['dob'] = this.quoteDetails['userDetails']['dob'];
    //   this.data['insured']['email'] = this.quoteDetails['userDetails']['email'];
    //   this.data['insured']['gender'] = this.quoteDetails['userDetails']['gender'];
    //   this.data['insured']['nationality'] = this.quoteDetails['userDetails']['nationality'];
    //   this.data['insured']['mobileCode'] = this.quoteDetails['userDetails']['mobileCode'];
    //   this.data['insured']['mobileNo'] = this.quoteDetails['userDetails']['mobileNo'];
    //   this.data['insured']['phoneCode'] = this.quoteDetails['userDetails']['mobileCode'];
    //   this.data['insured']['phoneNo'] = this.quoteDetails['userDetails']['mobileNo'];
    //   this.data['insured']['customerType'] = "I";
    //   this.data['insured']['address1'] = this.quoteDetails['userDetails']['address1'];
    //   this.data['insured']['address2'] = this.quoteDetails['userDetails']['address2'];
    //   this.data['insured']['address4'] = this.quoteDetails['userDetails']['address4'];
    //   this.data['insured']['city'] = this.quoteDetails['userDetails']['city'];
    //   this.data['insured']['postBox'] = this.quoteDetails['userDetails']['postBox'];
    //   this.data['insured']['country'] = this.quoteDetails['userDetails']['country'];
    //   this.data['travelDetails']['existingProd'] = this.quoteDetails['travelDetails']['existingProd'];
    //   this.data.quoteId = this.quoteDetails['quoteId'];
    //   console.log( this.data.quoteId);

    //   this.spinner.show();
    //   this.coreService.saveInputs('fetchAllPlansWithRate', this.data, null).subscribe(response => {
    //     this.planOb = response;
    //     this.spinner.hide();
    //     if (this.planOb) {
    //       this.isPlanAvailable = true;
    //       this.loadVATandPremium();
    //       this.loadCovers();
    //       this.isContentLoaded = true;
    //       this.initLoading();
    //       this.loadExcess();

    //     } else {
    //       this.isPlanAvailable = false;
    //     }
    //     localStorage.setItem('isPlanCalculated', 'true');
    //     let HomePageLoader = '';
    //     this.dataService.setMotorPageLoaderContent(HomePageLoader);
    //     this.dataService.setPlanDetails(response);
    //   },
    //   err => {
    //     this.isPlanAvailable = false;
    //     this.spinner.hide();
    //   });
    // });
    // }
  }
  ngDoCheck() {
    if (this.language != localStorage.getItem("language")) {
      this.language = localStorage.getItem("language");
    }
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
    if (this.planOb['discountsAvailable']) {
      this.applyDiscounts();
    }
    let data = this.appService.getDiscountDetails();
    if (data['discountsAvailable']) {
      this.planOb['discountCode'] = data['discountCode']
      this.applyDiscounts();
    }
  }

  loadCovers() {
    this.mandatoryCovers = {};
    let temp = true;
    this.planOb['plans'].forEach((plan, index) => {
      if (plan.prodID === this.runtimeConfigService.config.travel_insurance) {
        temp = true
      }
      let pgroup = this.promoDiscounts['Promotional Discount'] || [];
      if (pgroup.length == 0) this.promoDiscounts['Promotional Discount'] = [];
      this.promoDiscounts['Promotional Discount'].push({
        planId: plan.planDetails[0].planId,
        amount: 0
      })
      plan['bgColor'] = index;
      plan['applyPromoDiscount'] = false;
      plan['promoFieldId'] = `promo${index}`
      if (plan.confirmed) {
        this.demo1TabIndex = index;
        this.isPlanSelected = true;
        this.selectedPlan['planId'] = plan.planDetails[0].planId;
        this.selectedPlanAmount = plan.planDetails[0].grossPremium;
      }
      if (localStorage.getItem('language') === 'en') {
        plan.planDetails[0].coverageDetails[0].mandatoryCoverages.forEach(
          cover => {
            if (cover.pcmCoverageDesc === 'Accidental Death (Common Carrier)' && index === 0 && temp === true) {
              this.mandatoryCovers['Accidental Death (Common Carrier)'] = [];
              // this.mandatoryCovers['Driver Cover'] = [];
              //  this.mandatoryCovers['Oman Cover (Including Oman Territories inside UAE)'] = [];
            }
            if (cover.pcmCoverageDesc === 'Accidental Death (Common Carrier)' && index === 0 && temp === true) {
              this.mandatoryCovers['Accidental Death (Common Carrier)'] = [];
              //  this.mandatoryCovers['Driver Cover'] = [];
              //  this.mandatoryCovers['Oman Cover (Including Oman Territories inside UAE)'] = [];
            }
            //let cvrGroup = this.mandatoryCovers[cover.pcmCoverageDesc] || [];
            let cvrGroup = this.mandatoryCovers[cover.pcmCoverageDesc];
            // if (cvrGroup.length == 0)
            //  this.mandatoryCovers[cover.pcmCoverageDesc] = [];
            this.mandatoryCovers[cover.pcmCoverageDesc].push({
              planId: plan.planDetails[0].planId,
              cover: cover
            });
          });
      } else {
        plan.planDetails[0].coverageDetails[0].mandatoryCoverages.forEach(
          cover => {
            if (cover.pcmCoverageDesc1 === 'خدمة الإسعاف' && index === 0 && temp === true) {
              this.mandatoryCovers['خدمة الإسعاف'] = [];
              this.mandatoryCovers['تأمین السائق'] = [];
              this.mandatoryCovers['(بما في ذلك أقاليم عمان داخل الإمارات العربية المتحدة) غطاء عُمان'] = [];
            }
            let cvrGroup = this.mandatoryCovers[cover.pcmCoverageDesc1] || [];
            if (cvrGroup.length == 0)
              this.mandatoryCovers[cover.pcmCoverageDesc1] = [];
            this.mandatoryCovers[cover.pcmCoverageDesc1].push({
              planId: plan.planDetails[0].planId,
              cover: cover
            });
          });
      }
      plan.planDetails[0].coverageDetails[0].optionalCoverages.forEach(
        cover => {
          let cvrGroup = this.optionalCovers[cover.pcmCoverageDesc] || [];
          if (cvrGroup.length == 0)
            this.optionalCovers[cover.pcmCoverageDesc] = [];
          this.optionalCovers[cover.pcmCoverageDesc].push({
            planId: plan.planDetails[0].planId,
            cover: cover
          });
        }
      );
    });
    // To remove empty hardcoded covers
    // if (!temp)
    // return 
    // if (this.mandatoryCovers['Oman Cover (Including Oman Territories inside UAE)'].length === 0) {
    //   delete this.mandatoryCovers['Oman Cover (Including Oman Territories inside UAE)']
    // }
    // if (this.mandatoryCovers['Ambulance Cover'].length === 0) {
    //   delete this.mandatoryCovers['Ambulance Cover']
    // }
    // if (this.mandatoryCovers['Driver Cover'].length === 0) {
    //   delete this.mandatoryCovers['Driver Cover']
    // }
  }

  getData(searchKey, values): boolean {
    let isAvailable = false;
    values.forEach(value => {
      if (value.planId == searchKey) {
        if (value.cover.selected) {
          isAvailable = true;
        }
      }
    });
    return isAvailable;
  }

  getOptionalData(searchKey, values): boolean {
    let isAvailable = false;
    values.forEach(value => {
      if (value) {
        if (value.planId == searchKey) {
          isAvailable = true;
        }
      }
    });
    return isAvailable;
  }

  selectPlan(selectedPlan) {
    this.isPlanSelected = true;
    this.selectedPlan['planId'] = selectedPlan.planDetails[0].planId;
    this.selectedPlanAmount = selectedPlan.planDetails[0].grossPremium
    this.planOb['plans'].filter((plan) => {
      if (plan.planDetails[0].planId === this.selectedPlan['planId']) {
        plan.confirmed = true;
      } else {
        plan.confirmed = false;
      }
    });
  }
  confirmPlan() {
    if (!this.isPlanSelected) {
      this.translate.get('Required.SelectPlan').subscribe(value => {
        this.selectAlert = value;
      });
      swal(
        '', this.selectAlert, 'error'
      );
    }
    else if (this.selectedPlanAmount == '0' || this.selectedPlanAmount == null) {
      this.translate.get('Required.RatingError').subscribe(value => {
        this.ratingError = value;
      });
      swal(
        '', this.ratingError, 'error'
      );
    }
    else {
      if (this.showPromoDiscount) {
        this.planOb['discountsAvailable'] = true;
        this.planOb['promoDiscounts'] = this.promoDiscounts;
        this.planOb['discountCode'] = this.discountCode
      } else {
        this.planOb['discountsAvailable'] = false;
      }
      this.appService.setPlanDetails(this.planOb);
      let params = {
        quoteId: this.planOb['quoteId'],
        amndVerNo: this.planOb['amndVerNo'],
        planId: this.selectedPlan['planId']
      };

      this.coreService.saveInputs('confirmPlan', params, null).subscribe(res => {
        this.router.navigate([`/travelquotesummary`], { queryParams: { quoteNo: this.planOb['quoteNo'], isQuickSummary: true } });
      });
    }
  }
  doCall(plan, value) {
    let selCoverage = value.filter(
      ({ planId }) => planId == plan.planDetails[0].planId
    )[0].cover;
    if (selCoverage.selected) {
      return true
    }
    return false;
  }

  toggleCoverage(plan, covers, event) {
    this.spinner.show();
    let selCoverage = covers.filter(
      ({ planId }) => planId == plan.planDetails[0].planId
    )[0].cover;
    let params = {
      coverageId: selCoverage.pcmCoverageId,
      isChecked: event.checked,
      sgsId: this.planOb['quoteId'],
      productId: this.planOb['productId'],
      planId: plan.planDetails[0].planId,
    };

    this.coreService
      .saveInputs("fetchnIndividualPlansWithRate", params, null)
      .subscribe(response => {
        plan.planDetails[0].grossPremium = response.data.grossPremium;
        if (plan.planDetails[0].planId === this.selectedPlan['planId'])
          this.selectedPlanAmount = response.data.grossPremium;
        this.spinner.hide();
      }, err => {
        this.spinner.hide();
      });
  }

  goBack() {
    let value;
    if (this.showPromoDiscount) {
      value = {
        discountsAvailable: true,
        promoDiscounts: this.promoDiscounts,
        discountCode: this.discountCode
      }
    } else {
      value = {
        discountsAvailable: false
      }
    }
    this.appService.setDiscountDetails(value);
    if (!this.planOb) {
      this.router.navigate(['/travelinfo']);
      return
    }
    this.router.navigate(['/travelinfo'],
      {
        queryParams: {
          quoteNo: this.planOb['quoteId']
        }
      });
  }

  isSelectedPlan(value) {
    if (value.confirmed)
      return true;
  }

  loadExcess() {
    this.planOb['plans'].forEach(plan => {
      let i = 0;
      plan.excess.forEach(item => {
        // if (item.description === "Excess") {
        let group = this.excess[item.description] || [];
        if (group.length == 0) this.excess[item.description] = [];
        // if (i === 0) {
        //   i++;
        this.excess[item.description].push({
          planId: plan.planDetails[0].planId,
          id: item.id,
          ratePer: item.ratePer,
          rate: item.rate,
          amount: item.amount
        });
        // }
        // }
      });
    });
  }

  loadVATandPremium() {
    this.planOb['plans'].forEach(plan => {
      plan.planDetails[0]['premiumWithCharges'] = 0;
      plan.planDetails[0]['premiumWithVAT'] = 0;
      let premiumWithCharge = 0;
      let premiumWithVat = 0;
      plan.charges.forEach(item => {
        if (item.description === 'Premium VAT') {
          let group = this.charges[item.description] || [];
          if (group.length == 0) this.charges[item.description] = [];
          this.charges[item.description].push({
            planId: plan.planDetails[0].planId,
            id: item.id,
            ratePer: item.ratePer,
            rate: item.rate,
            amount: item.amount
          });
          premiumWithVat += item.amount;
        } else {
          premiumWithCharge += item.amount
        }
      });
      plan.planDetails[0]['premiumWithVAT'] = premiumWithVat + parseFloat(plan.planDetails[0]['grossPremium']);
      plan.planDetails[0]['premiumWithCharges'] = premiumWithCharge + plan.planDetails[0]['txnPremium'];
    });
  }

  getPremiumWithCharges(plan) {
    if (plan.premiumWithCharges) {
      return plan.premiumWithCharges.toFixed(2);
    }
    return '0.00';
  }

  getPremiumWithVat(plan) {
    if (plan.premiumWithVAT) {
      return plan.premiumWithVAT.toFixed(2);
    }
    return '0.00';
  }

  getNetPremium(plan) {
    if (plan.grossPremium) {
      return parseFloat(plan.grossPremium).toFixed(2);
    }
    return '0.00';
  }
  getSumInsured(plan) {
    if (plan.sumInsured) {
      return parseFloat(plan.sumInsured).toFixed(2);
    }
    return '0.00';
  }

  fetchAmount(searchKey, values, type) {
    let amount;
    let obj = values.filter(({ planId }) => planId == searchKey)[0];
    if (obj) {
      if (obj.amount == null) amount = 0;
      else amount = obj.amount;
      if (type === 'P') {
        this.VatPercentage = `${obj.rate}%`;
      }
      return `${amount.toFixed(2)}`;
    }
  }

  fetchAmountMobile(searchKey, values, type) {
    let amount;
    let obj = values.filter(({ planId }) => planId == searchKey)[0];
    if (obj) {
      if (obj.amount == null) amount = 0;
      else amount = obj.amount;
      if (type === 'P') {
        this.VatPercentage = `(${obj.rate}%)`;
      }
      return `${amount.toFixed(2)}`;
    }
  }

  isNotEmpty = obj => Object.keys(obj).length > 0;

  initLoading() {
    this.planOb['plans'].forEach(plan => {
      plan.loading.forEach(item => {
        if (item.id === '1002')
          return;
        let group = this.discounts[item.description] || [];
        if (group.length == 0) this.discounts[item.description] = [];
        if (item.id === '1002') {
          this.discounts[item.description].push({
            planId: plan.planDetails[0].planId,
            id: item.id,
            ratePer: item.ratePer,
            rate: item.rate,
            amount: item.amount
          });
        } else {
          this.discounts[item.description].push({
            planId: plan.planDetails[0].planId,
            id: item.id,
            ratePer: item.ratePer,
            rate: item.rate,
            amount: item.amount
          });
        }
      });
    });
  }

  onTabChanged(event) {
    this.isPlanSelected = true;
    this.selectedPlan['planId'] = this.planOb['plans'][event.index].planDetails[0].planId;
    this.selectedPlanAmount = this.planOb['plans'][event.index].planDetails[0].grossPremium
    this.planOb['plans'].filter((plan) => {
      if (plan.planDetails[0].planId === this.selectedPlan['planId']) {
        plan.confirmed = true;
      } else {
        plan.confirmed = false;
      }
    });
  }

  planselectMob(selectedPlan) {
    this.isPlanSelected = true;
    this.selectedPlan['planId'] = selectedPlan.planDetails[0].planId;
    this.selectedPlanAmount = selectedPlan.planDetails[0].grossPremium
    this.planOb['plans'].filter((plan) => {
      if (plan.planDetails[0].planId === this.selectedPlan['planId']) {
        plan.confirmed = true;
      } else {
        plan.confirmed = false;
      }
    });
  }

  addPromoDiscount(response) {
    this.charges['Premium VAT'].forEach((element, index) => {
      element.amount = parseFloat(response.plans[index].vat)
    });
    this.planOb['plans'].filter((plan, index) => {
      if (plan.planDetails[0].planId === response.plans[index].planId) {
        plan.planDetails[0]['grossPremium'] = response.plans[index].grossPremium;
        plan.planDetails[0]['premiumWithVAT'] = parseFloat(response.plans[index].vat) + parseFloat(response.plans[index]['grossPremium']);
        plan.applyPromoDiscount = true;
        this.promoDiscounts['Promotional Discount'].forEach((item, index) => {
          if (item.planId === response.plans[index].planId) {
            if (response.plans[index].loading.length > 1) {
              item.amount = response.plans[index].loading[1].amount
            } else {
              item.amount = response.plans[index].loading[0].amount
            }
          }
        });
      }
    });
    this.showPromoDiscount = true;
  }

  removeDiscounts(response) {
    this.charges['Premium VAT'].forEach((element, index) => {
      element.amount = parseFloat(response.plans[index].vat)
    });
    this.planOb['plans'].filter((plan, index) => {
      if (plan.planDetails[0].planId === response.plans[index].planId) {
        plan.planDetails[0]['grossPremium'] = response.plans[index].grossPremium;
        plan.planDetails[0]['premiumWithVAT'] = parseFloat(response.plans[index].vat) + parseFloat(response.plans[index]['grossPremium']);
        plan.applyPromoDiscount = false;
        this.promoDiscounts['Promotional Discount'].forEach((item, index) => {
          if (item.planId === response.plans[index].planId) {
            if (response.plans[index].loading.length > 1) {
              item.amount = response.plans[index].loading[1].amount
            } else {
              item.amount = response.plans[index].loading[0].amount
            }
          }
        });
      }
    });
  }




  applyDiscounts() {
    if (window.screen.width < 990) {
      this.planOb['plans'].forEach(plan => {
        let x: any = (<HTMLInputElement>document.getElementById(plan.promoFieldId));
        x.value = this.planOb['discountCode'];
        x.disabled = true;
      });
      this.onBlurMethodMob(this.planOb['discountCode'], 'bind')
    } else {
      let x: any = (<HTMLInputElement>document.getElementById('promoInputField'));
      x.value = this.planOb['discountCode'];
      this.onBlurMethod('promoInputField')
    }
  }

  onBlurMethodMob(event, type) {
    let code;
    if (type)
      code = event;
    else
      code = event.target.value;
    if (!code) {
      return
    }
    this.spinner.show();
    this.discountCode = code;
    let id = this.planOb['quoteId'];
    console.log(id);
    let param = {
      discountCode: code,
      quoteId: id
    }
    this.coreService.postInputs7(`discount/applyPromocode`, '', param).subscribe((response) => {
      this.spinner.hide();
      if (response) {
        this.planOb['plans'].forEach(plan => {
          let x: any = (<HTMLInputElement>document.getElementById(plan.promoFieldId));
          x.value = code;
          x.disabled = true;
        });
        response = JSON.parse(response);
        this.addPromoDiscount(response)
      }
    }, err => {
      this.spinner.hide();
      if (!type)
        event.target.value = '';
    })
  }

  onBlurMethod(field) {
    let x: any = (<HTMLInputElement>document.getElementById(field));
    let code = x.value;
    if (!code) {
      return
    }
    this.spinner.show();
    this.discountCode = code;
    let id = this.planOb['quoteId'];
    console.log(id);
    let param = {
      discountCode: code,
      quoteId: id
    }
    this.coreService.postInputs7(`discount/applyPromocode`, '', param).subscribe((response) => {
      this.spinner.hide();
      if (response) {
        response = JSON.parse(response);
        x.disabled = true;
        this.addPromoDiscount(response)
      }
    }, err => {
      this.spinner.hide();
      x.value = '';
    })
  }

  removePromoDiscount(id) {
    this.showPromoDiscount = false;
    this.discountCode = null;
    let x = (<HTMLInputElement>document.getElementById(id));
    let code = x.value;
    x.value = '';
    x.disabled = false;
    this.spinner.show();
    this.discountCode = code;
    let id1 = this.planOb['quoteId'];
    let param = {
      discountCode: code,
      quoteId: id1
    }
    this.coreService.postInputs7(`discount/removePromocode`, '', param).subscribe((response) => {
      this.spinner.hide();
      if (response) {
        response = JSON.parse(response);
        x.disabled = false;
        this.removeDiscounts(response)
      }
    }, err => {
      this.spinner.hide();
      x.value = '';
    })
  }

  removePromoDiscountMob(id) {
    this.showPromoDiscount = false;
    this.discountCode = null;
    let x = (<HTMLInputElement>document.getElementById(id));
    let code = x.value;
    this.planOb['plans'].forEach(plan => {
      let x: any = (<HTMLInputElement>document.getElementById(plan.promoFieldId));
      x.value = '';
      x.disabled = false;
    });
    this.spinner.show();
    this.discountCode = code;
    let id1 = this.planOb['quoteId'];
    let param = {
      discountCode: code,
      quoteId: id1
    }
    this.coreService.postInputs7(`discount/removePromocode`, '', param).subscribe((response) => {
      this.spinner.hide();
      if (response) {
        response = JSON.parse(response);
        x.disabled = false;
        this.removeDiscounts(response)
      }
    }, err => {
      this.spinner.hide();
      x.value = '';
    })
  }
  openImageDialog(plan: any): void {
    this.dialog.open(ShowImage, {
      direction: localStorage.getItem('language') === 'ar' ? 'rtl' : 'ltr',
      autoFocus: false,
      disableClose: true,
      data: { productId: plan.prodID, planId: plan.planDetails[0].planId }
    });
  }
}
