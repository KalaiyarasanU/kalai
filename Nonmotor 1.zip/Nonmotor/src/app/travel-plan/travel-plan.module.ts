import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppMaterialModule } from '../app-material.module';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';

import { TravelPlanRoutingModule } from './travel-plan-routing.module';
import { PlanComponent } from './plan/plan.component';
import { TranslateModule } from '@ngx-translate/core';
import { CoreModule } from '../core/core.module';



@NgModule({
  declarations: [PlanComponent],
  imports: [
    AppMaterialModule, 
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    CommonModule,
    CoreModule,
    TravelPlanRoutingModule,
    TranslateModule
  ]
})
export class TravelPlanModule { }
