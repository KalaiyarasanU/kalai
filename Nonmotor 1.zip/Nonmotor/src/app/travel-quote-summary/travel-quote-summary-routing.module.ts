import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { QuoteSummaryComponent } from './quote-summary/quote-summary.component';


const routes: Routes = [ {
  path: '', component: QuoteSummaryComponent
},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TravelQuoteSummaryRoutingModule { }
