(function() {
    var w = window
      , C = '___grecaptcha_cfg'
      , cfg = w[C] = w[C] || {}
      , N = 'grecaptcha';
    var gr = w[N] = w[N] || {};
    gr.ready = gr.ready || function(f) {
        (cfg['fns'] = cfg['fns'] || []).push(f);
    }
    ;
    w['__recaptcha_api'] = 'https://www.google.com/recaptcha/api2/';
    (cfg['render'] = cfg['render'] || []).push('explicit');
    (cfg['onload'] = cfg['onload'] || []).push('ngx_captcha_onload_callback');
    w['__google_recaptcha_client'] = true;
    var d = document
      , po = d.createElement('script');
    po.type = 'text/javascript';
    po.async = true;
    console.log('recapppp')
    po.src = 'https://www.gstatic.com/recaptcha/releases/jxFQ7RQ9s9HTGKeWcoa6UQdD/recaptcha__en.js';
    po.crossOrigin = 'anonymous';
    po.integrity = 'sha384-M9863pj8VTkCmdbfuuaGvQUaNXo72mc4KbfOtDfVBjv+zjrQy0vx5uzX9BsGSepE';
    var e = d.querySelector('script[nonce]')
      , n = e && (e['nonce'] || e.getAttribute('nonce'));
    if (n) {
        po.setAttribute('nonce', n);
    }
    var s = d.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(po, s);
}
)();