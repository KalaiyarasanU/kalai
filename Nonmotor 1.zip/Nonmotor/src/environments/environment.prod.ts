export const environment = {
  production: true,

  DevEndpointdbsync: 'http://192.168.1.247:24090/bts-broker-portal/api/dbsync/',
  DevEndpoint: 'http://192.168.2.123:24090/bts-portal/api/bts-service/',
  PaymentEndpoint: 'http://192.168.50.189:8900/payment-service/'
};