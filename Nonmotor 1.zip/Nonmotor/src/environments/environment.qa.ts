export const environment = {
    production: false,
    environmentName: 'QA',

  DevEndpointdbsync: 'http://192.168.2.105:29590/bts-broker-portal/api/dbsync/',
  DevEndpoint: 'http://192.168.2.105:29590/bts-broker-portal/api/',
  PaymentEndpoint: 'https://192.168.2.105:29590/bts-broker-portal/api/payment-service/',
};