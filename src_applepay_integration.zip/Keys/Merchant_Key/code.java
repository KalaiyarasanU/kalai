import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

public class RestClient {

    public static void main(String[] args) throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException, UnrecoverableKeyException, KeyManagementException {
        // Load the SSL certificate
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        try (FileInputStream fileInputStream = new FileInputStream("path/to/your/certificate.p12")) {
            keyStore.load(fileInputStream, "your_certificate_password".toCharArray());
        }

        // Set up the SSL context with the loaded certificate
        SSLContext sslContext = SSLContextBuilder
                .create()
                .loadKeyMaterial(keyStore, "your_certificate_password".toCharArray())
                .build();

        // Configure the SSL socket factory
        SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

        // Set up the request factory with the SSL socket factory
        ClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory() {
            @Override
            protected void prepareConnection(java.net.HttpURLConnection connection, String httpMethod) throws IOException {
                if (connection instanceof javax.net.ssl.HttpsURLConnection) {
                    ((javax.net.ssl.HttpsURLConnection) connection).setSSLSocketFactory(sslSocketFactory);
                }
                super.prepareConnection(connection, httpMethod);
            }
        };

        // Use a RestTemplate with SSL configuration
        RestTemplate restTemplate = new RestTemplate(requestFactory);

        // Set up the request headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", "Bearer your_access_token"); // If needed

        // Set up the request entity
        HttpEntity<String> requestEntity = new HttpEntity<>("your_request_body", headers);

        // Set the URL
        String url = "https://your-api-endpoint.com/api/resource";

        // Make the POST request
        ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, String.class);

        // Handle the response
        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            String responseBody = responseEntity.getBody();
            System.out.println("Response: " + responseBody);
        } else {
            System.err.println("Request failed with status code: " + responseEntity.getStatusCode());
        }
    }
}




@Bean
public RestTemplate restTemplate(RestTemplateBuilder builder) throws Exception {
    char[] password = "password".toCharArray();
    SSLContext sslContext = SSLContextBuilder.create()
            .loadKeyMaterial(keyStore("classpath:cert.jks", password), password)
            .loadTrustMaterial(null, new TrustSelfSignedStrategy()).build();
    HttpClient client = HttpClients.custom().setSSLContext(sslContext).build();
    return builder.requestFactory(new HttpComponentsClientHttpRequestFactory(client)).build();
}

private KeyStore keyStore(String file, char[] password) throws Exception {
    KeyStore keyStore = KeyStore.getInstance("PKCS12");
    File key = ResourceUtils.getFile(file);
    try (InputStream in = new FileInputStream(key)) {
        keyStore.load(in, password);
    }
    return keyStore;
}

@Autowired
private RestTemplate restTemplate;

public List<Info> getInfo() throws RestClientException, URISyntaxException {
    HttpEntity<?> httpEntity = new HttpEntity<>(null, new HttpHeaders());
    ResponseEntity<Info[]> resp = restTemplate.exchange(new URI(BASE_URL + "/Info"), HttpMethod.GET, httpEntity, Info[].class);
    return Arrays.asList(resp.getBody());
}

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class CybersourceApplePayExample {

    public static void main(String[] args) {
        // Replace with your Cybersource credentials
        String merchantId = "your_merchant_id";
        String transactionKey = "your_transaction_key";

        try {
            // Construct the Cybersource API endpoint
            String cybersourceEndpoint = "https://api.cybersource.com/pts/v2/payments";

            // Create the authorization header
            String credentials = merchantId + ":" + transactionKey;
            String base64Credentials = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));

            // Create the Cybersource payment request for Apple Pay
            String cybersourceRequestBody = "{"
                    + "\"clientReferenceInformation\": {"
                    + "    \"code\": \"TC50171_3\""
                    + "},"
                    + "\"processingInformation\": {"
                    + "    \"commerceIndicator\": \"internet\""
                    + "},"
                    + "\"orderInformation\": {"
                    + "    \"amountDetails\": {"
                    + "        \"totalAmount\": \"100.00\","
                    + "        \"currency\": \"USD\""
                    + "    }"
                    + "},"
                    + "\"paymentInformation\": {"
                    + "    \"applepay\": {"
                    + "        \"data\": \"your_apple_pay_data\","
                    + "        \"header\": \"your_apple_pay_header\","
                    + "        \"signature\": \"your_apple_pay_signature\","
                    + "        \"version\": \"1.0\""
                    + "    }"
                    + "}"
                    + "}";

            // Create the HTTP connection
            URL url = new URL(cybersourceEndpoint);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Basic " + base64Credentials);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            // Send the Cybersource payment request
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = cybersourceRequestBody.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            // Get the Cybersource payment response
            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // Handle the response accordingly
            // ...

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
