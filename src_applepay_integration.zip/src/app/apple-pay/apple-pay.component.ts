import { AfterViewInit, Component, ElementRef, OnInit, Renderer2, RendererStyleFlags2, ViewChild } from '@angular/core';


import { billTo, orderInformation, amountDetails } from './modules/cybersoucepayload';

import { ApplePayService } from './apple-pay.service';


import * as https from 'https';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { error } from 'console';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-apple-pay',
  templateUrl: './apple-pay.component.html',
  styleUrls: ['./apple-pay.component.scss']
})
export class ApplePayComponent implements AfterViewInit {

  @ViewChild('applePay', { static: false }) public but: ElementRef<any>;
  constructor(private renderer: Renderer2, public appleservice: ApplePayService, public http: HttpClient) {
  }

  ngAfterViewInit() {



    if (!(window as any).ApplePaySession) {
      console.error('This device does not support Apple Pay');
    }

    if (!(window as any).ApplePaySession.canMakePayments()) {
      console.error('This device is not capable of making Apple Pay payments');
    }
    if (!(window as any).ApplePaySession.supportsVersion(3)) {
      console.error('This device is not capable of making Apple Pay payments in version-3');
    }
    if ((window as any).ApplePaySession && (window as any).ApplePaySession.supportsVersion(3) && (window as any).ApplePaySession.canMakePayments()) {
      // This device supports version 3 of Apple Pay.
      const button = this.renderer.createElement('apple-pay-button');
      this.renderer.setAttribute(this.but.nativeElement, 'buttonstyle', 'black');
      this.renderer.setAttribute(this.but.nativeElement, 'type', 'buy');
      this.renderer.setAttribute(this.but.nativeElement, 'locale', 'el-GR');
      this.renderer.setStyle(this.but.nativeElement, 'display', 'inline-bloc', RendererStyleFlags2.Important);
      this.renderer.appendChild(this.but.nativeElement, button);
    }

  }
appleclick(url){
 
    this.http.get('https://jsonplaceholder.typicode.com/users').subscribe((res)=>{
        console.log(res);
    });

}
  onApplePayClick() {




    console.log('On Apple Pay Clicked');
    // Define ApplePayPaymentRequest
    const request = {
      "countryCode": "AE",
      "currencyCode": "AED",
      "merchantCapabilities": [
        "supportsCredit",
        "supportsDebit",
        "supports3DS"
      ],
      "supportedNetworks": [
        "amex",
        "discover",
        "maestro",
        "masterCard",
        "visa"
      ],
      "lineItems": [
        {
          "label": "Premium Subtotal",
          "type": "final",
          "amount": "10.00"
        },
        {
          "label": "Free Shipping",
          "amount": "0.00",
          "type": "final"
        },
        {
          "label": "Estimated Tax",
          "amount": "0.00",
          "type": "final"
        }
      ],
      "total": {
        "label": "DIC Demo",
        "type": "final",
        "amount": "10.00"
      }


    };

    // Create ApplePaySession
    const session = new (window as any).ApplePaySession(3, request);

    session.onvalidatemerchant = async (event: any) => {
      console.log('Inside On Validate Merhant');
      this.appleservice.getApplePaySession(event.validationURL).subscribe(
        merchantSession => {
          console.log('SUCCESS in merchantsession --', merchantSession);
          session.completeMerchantValidation(merchantSession);
        },
        error => {
          console.log('ERROR in merchantsession --', error);
          session.abort();
        }
      );


    };

    session.onpaymentmethodselected = (event: any) => {
      // Define ApplePayPaymentMethodUpdate based on the selected payment method.
      // No updates or errors are needed, pass an empty object.
      console.log(' INSIDE completePaymentMethodSelection')
      var paymentMethod = event.paymentMethod;
      console.log('paymentMethod --' + paymentMethod);
      // Create a new total using ApplePayLineItem
      var newTotal = ({
        label: 'Total',
        amount: '10.00', // Example amount
        type: 'final' // 'final' indicates the total amount
      });

      // Update the payment method with the new total
      session.completePaymentMethodSelection({
        newTotal: newTotal
      });
      console.log('completePaymentMethodSelection -- Completed')
    }

    session.onshippingmethodselected = (event: any) => {
      // Define ApplePayShippingMethodUpdate based on the selected shipping method.
      // No updates or errors are needed, pass an empty object. 
      const update = {};
      session.completeShippingMethodSelection(update);
    };

    session.onshippingcontactselected = (event: any) => {
      // Define ApplePayShippingContactUpdate based on the selected shipping contact.
      const update = {};
      session.completeShippingContactSelection(update);
    };

    session.onpaymentauthorized = (event: any) => {
      console.log('Inside onpaymentauthorized');
      var paymentDataString = JSON.stringify(event.payment.token.paymentData);
      var paymentDataBase64 = btoa(paymentDataString);
      console.log(paymentDataBase64);

      this.appleservice.authorize(paymentDataBase64).subscribe(
        data => {
          console.log('cybersourcedata', data);
          if (data != null) {
            if (data.status == 'AUTHORIZED') {
              session.completePayment((window as any).ApplePaySession.STATUS_SUCCESS);
              //redirect to payment success page
              alert("Transaction status - " + data.status  +" and Order id - " + data.id );
            } else {
              alert(data.errorInformation.reason + " , Message --" + data.errorInformation.message);
              session.abort();
            }
          } else {
            session.abort();
          }
        }, error => {
          console.log('ERROR : in Authorize', error);
        });


    };

    session.oncouponcodechanged = event => {
      // Define ApplePayCouponCodeUpdate
      // const newTotal = calculateNewTotal(event.couponCode);
      // const newLineItems = calculateNewLineItems(event.couponCode);
      // const newShippingMethods = calculateNewShippingMethods(event.couponCode);
      // const errors = calculateErrors(event.couponCode);
      // const newTotal = calculateNewTotal(event.couponCode);
      // const newLineItems = calculateNewLineItems(event.couponCode);
      // const newShippingMethods = calculateNewShippingMethods(event.couponCode);
      // const errors = calculateErrors(event.couponCode);
      // session.completeCouponCodeChange({
      //     newTotal: newTotal,
      //     newLineItems: newLineItems,
      //     newShippingMethods: newShippingMethods,
      //     errors: errors,
      // });
    };

    session.oncancel = event => {
      // Payment canceled by WebKit
    };

    session.begin();
  }

}

