import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { environment } from '../../environments/environment.prod';
import * as shajs from 'sha.js';
import * as CryptoJS from 'crypto-js';
import { Buffer } from 'buffer';
import { clientReferenceInformation, billTo, cybersourcePayloads, paymentInformation, tokenizedCard, orderInformation, processingInformation, amountDetails, fluidData } from './modules/cybersoucepayload';


@Injectable({
  providedIn: 'root'
})
export class ApplePayService {

  constructor(public http: HttpClient) { }

  getApplePaySession(validationURL: any) {    
    let body  = JSON.stringify({
      validationURL:validationURL,      
      merchantIdentifier: "merchant.dubaiins.mohresandbox",
      displayName: "Apple Pay Test",
      initiative: "web",
      initiativeContext: "uatsrv.dubins.ae"}
    );
    let header = new HttpHeaders();
    header = header.set('Content-Type', 'application/json; charset=utf-8');
    return this.http.post(
      'https://uatsrv.dubins.ae/ApplePay/api/applepay/getMerchantSession', body, { headers: header }).pipe(map((res: any) => {        
        return res;
      }));
  }

  authorize(paymentdata:any){
    let body =JSON.stringify({ applePayData:paymentdata,
    type:"002",
    totalAmount:"10",
    currency:"AED",
    firstName:"Kalai",
    lastName:"Arasan",
    address1:"block-7",
    locality:"Dubai",
    administrativeArea:"CA",
    postalCode:"625531",
    country:"AE",
    email:"kalaiyarasan.u@azentio.com",
    transactionType:"1"});    
    let header = new HttpHeaders();
    header = header.set('Content-Type', 'application/json; charset=utf-8');
    return this.http.post(
      'https://uatsrv.dubins.ae/ApplePay/api/cybersource/paymentAuthorize', body, { headers: header }).pipe(map((res: any) => {        
        return res;
      }));
  }



  // getcybersoucePayload(paymentdata: any){
  //   let body :any;
  //   if(cardtype=='VISA'){
  //   let ClientReferenceInformation = new clientReferenceInformation();   
  //   let ProcessingInformation = new processingInformation();
  //   let FluidData = new fluidData();
  //   FluidData.value = paymentdata;
  //   let TokenizedCard = new tokenizedCard();
  //   if(cardtype=='MC'){
  //   TokenizedCard.type='002';
  //   }
  //   let PaymentInformation = new paymentInformation();
  //   PaymentInformation.fluidData = FluidData
  //   PaymentInformation.tokenizedCard = TokenizedCard;
  //   let cybersourcePayload = new cybersourcePayloads();

  //   cybersourcePayload.clientReferenceInformation = ClientReferenceInformation,
  //   cybersourcePayload.processingInformation = ProcessingInformation,
  //   cybersourcePayload.paymentInformation = PaymentInformation,
  //   cybersourcePayload.orderInformation = OrderInformation


  //   let payload = JSON.stringify(cybersourcePayload);
  //   console.log('payload', payload);
  //   let payloadhash = shajs('sha256').update(payload).digest('hex');
  //   console.log('payloadhash', payloadhash)
  //   let digest = "SHA-256=" + btoa(payloadhash);//payload hash base64
  //   console.log('digest', digest);
  //   let signatureParams = "host: apitest.cybersource.com";
  //   signatureParams += "/n date:" + new Date().toUTCString();
  //   signatureParams += "/n request-target: post /pts/v2/payments/";
  //   signatureParams += "/n digest: " + digest;
  //   signatureParams += "/n v-c-merchant-id:" + environment.cybersouceMerchantId;
  //   console.log('signatureParams --', signatureParams);
  //   let signature = this.generateSignatureFromParams(signatureParams, environment.sharedSecreatKey);
  //   console.log('signature --' + signature);

  //    body  = JSON.stringify({
  //     merchant_id: environment.cybersouceMerchantId,
  //     date: new Date().toUTCString(),
  //     digest: digest,
  //     signature: signature,
  //     payload:payload
  //   });
  // }
  //   return body;
  // }

  // public cyberSouceApicall(paymentdata: any, OrderInformation: orderInformation) {


  //   let ClientReferenceInformation = new clientReferenceInformation();   
  //   let ProcessingInformation = new processingInformation();
  //   let FluidData = new fluidData();
  //   FluidData.value = paymentdata;
  //   let TokenizedCard = new tokenizedCard();

  //   let PaymentInformation = new paymentInformation();
  //   PaymentInformation.fluidData = FluidData
  //   PaymentInformation.tokenizedCard = TokenizedCard;
  //   let Visa = new cybersourcePayloads();

  //   Visa.clientReferenceInformation = ClientReferenceInformation,
  //     Visa.processingInformation = ProcessingInformation,
  //     Visa.paymentInformation = PaymentInformation,
  //     Visa.orderInformation = OrderInformation


  //   let payload = JSON.stringify(Visa);
  //   console.log('payload', payload);
  //   let payloadhash = shajs('sha256').update(payload).digest('hex');
  //   console.log('payloadhash', payloadhash)
  //   let digest = "SHA-256=" + btoa(payloadhash);//payload hash base64
  //   console.log('digest', digest);
  //   let signatureParams = "host: apitest.cybersource.com";
  //   signatureParams += "/n date:" + new Date().toUTCString();
  //   signatureParams += "/n request-target: post /pts/v2/payments/";
  //   signatureParams += "/n digest: " + digest;
  //   signatureParams += "/n v-c-merchant-id:" + environment.cybersouceMerchantId;
  //   console.log('signatureParams --', signatureParams);
  //   let signature = this.generateSignatureFromParams(signatureParams, environment.sharedSecreatKey);
  //   console.log('signature --' + signature);
  //   // const headers = new HttpHeaders();
  //   // headers.append('Content-Type', 'application/json');
  //   // headers.append('Access-Control-Allow-Origin', '*');
  //   // headers.append('Access-Control-Allow-Headers', 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method');
  //   // headers.append('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  //   // headers.append('host', 'apitest.cybersource.com');
  //   // headers.append('v-c-merchant-id', environment.cybersouceMerchantId);
  //   // headers.append('v-c-date" ', new Date().toUTCString());
  //   // headers.append('digest', digest);
  //   // headers.append('signature', signature);


  //   return fetch(environment.CybersourceURL, {
  //     method: 'POST',
  //     body: payload,
  //     headers: {
  //       "Content-Type": "application/json",
  //       "Access-Control-Allow-Origin": "*",
  //       "Access-Control-Allow-Headers": "X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method",
  //       "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE",
  //       "host": "apitest.cybersource.com",
  //       "v-c-merchant-id": environment.cybersouceMerchantId,
  //       "v-c-date": new Date().toUTCString(),
  //       "digest": digest,
  //       "signature": signature

  //     },
  //   })
  //     .then((response) => response.json())
  //     .then(console.log);


  //   // return this.http.post(

  //   //   environment.CybersourceURL, payload, {headers:headers}).pipe(map((res: any) => {
  //   //     console.log('Merchant Response--', JSON.stringify(res));
  //   //     return res;
  //   //   }));


  // }
  // generateSignatureFromParams(signatureParams: string, secretKey: string): string {

  //   const sigBytes = Buffer.from(signatureParams, 'utf8');
  //   const decodedSecret = Buffer.from(secretKey, 'base64');
  //   const hmacSha256 = CryptoJS.HmacSHA256(signatureParams, CryptoJS.enc.Hex.parse(secretKey));
  //   //const messageHash = hmacSha256.update(sigBytes).digest();
  //   return btoa(hmacSha256);
  // }




}



