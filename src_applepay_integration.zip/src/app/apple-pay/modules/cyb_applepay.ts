import {
    ApiClient, CreatePaymentRequest, PaymentsApi, Ptsv2paymentsClientReferenceInformation,
    Ptsv2paymentsProcessingInformation, Ptsv2paymentsPaymentInformation,
    Ptsv2paymentsPaymentInformationTokenizedCard, Ptsv2paymentsOrderInformation,
    Ptsv2paymentsOrderInformationAmountDetails, Ptsv2paymentsOrderInformationBillTo
}
    from 'cybersource-rest-client';

import {Configuration} from '../modules/Data';

function digital_payments_applepay(callback: Function, enable_capture: boolean): void {
    try {
        const configObject = new Configuration();
        const apiClient = new ApiClient();
        const requestObj = new CreatePaymentRequest();

        const clientReferenceInformation = new Ptsv2paymentsClientReferenceInformation();
        clientReferenceInformation.code = 'TC_1231223';
        requestObj.clientReferenceInformation = clientReferenceInformation;

        const processingInformation = new Ptsv2paymentsProcessingInformation();
        processingInformation.capture = false;
        if (enable_capture === true) {
            requestObj.processingInformation.capture = true;
        }

        processingInformation.paymentSolution = '001';
        requestObj.processingInformation = processingInformation;

        const paymentInformation = new Ptsv2paymentsPaymentInformation();
        const paymentInformationTokenizedCard = new Ptsv2paymentsPaymentInformationTokenizedCard();
        paymentInformationTokenizedCard.number = '4111111111111111';
        paymentInformationTokenizedCard.expirationMonth = '12';
        paymentInformationTokenizedCard.expirationYear = '2031';
        paymentInformationTokenizedCard.cryptogram = 'AceY+igABPs3jdwNaDg3MAACAAA=';
        paymentInformationTokenizedCard.transactionType = '1';
        paymentInformation.tokenizedCard = paymentInformationTokenizedCard;

        requestObj.paymentInformation = paymentInformation;

        const orderInformation = new Ptsv2paymentsOrderInformation();
        const orderInformationAmountDetails = new Ptsv2paymentsOrderInformationAmountDetails();
        orderInformationAmountDetails.totalAmount = '10';
        orderInformationAmountDetails.currency = 'USD';
        orderInformation.amountDetails = orderInformationAmountDetails;

        const orderInformationBillTo = new Ptsv2paymentsOrderInformationBillTo();
        orderInformationBillTo.firstName = 'John';
        orderInformationBillTo.lastName = 'Deo';
        orderInformationBillTo.address1 = '901 Metro Center Blvd';
        orderInformationBillTo.locality = 'Foster City';
        orderInformationBillTo.administrativeArea = 'CA';
        orderInformationBillTo.postalCode = '94404';
        orderInformationBillTo.country = 'US';
        orderInformationBillTo.email = 'test@cybs.com';
        orderInformationBillTo.phoneNumber = '6504327113';
        orderInformation.billTo = orderInformationBillTo;

        requestObj.orderInformation = orderInformation;

        const instance = new PaymentsApi(configObject, apiClient);

        instance.createPayment(requestObj, function (error, data, response) {
            if (error) {
                console.log('\nError : ' + JSON.stringify(error));
            }
            else if (data) {
                console.log('\nData : ' + JSON.stringify(data));
            }

            console.log('\nResponse : ' + JSON.stringify(response));
            console.log('\nResponse Code of Process a Payment : ' + JSON.stringify(response['status']));
            const status = response['status'];
            
            callback(error, data, response);
        });
    }
    catch (error) {
        console.log('\nException on calling the API : ' + error);
    }
}





export { digital_payments_applepay };