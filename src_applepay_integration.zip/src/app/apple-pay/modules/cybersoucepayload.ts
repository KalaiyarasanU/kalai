export class cybersourcePayloads {
    clientReferenceInformation: clientReferenceInformation;
    processingInformation:      processingInformation;
    paymentInformation:         paymentInformation;
    orderInformation:           orderInformation;
}



export class clientReferenceInformation {
    code: string=new Date().getTime().toString();
}

export class orderInformation {
    amountDetails: amountDetails;
    billTo:        billTo;
}

export class amountDetails {
    totalAmount: string;
    currency:    string;
}

export class billTo {
    firstName:          string;
    lastName:           string;
    address1:           string;
    locality:           string;
    administrativeArea: string;
    postalCode:         string;
    country:            string;
    email:              string;
}

export class paymentInformation {
    fluidData:     fluidData;
    tokenizedCard: tokenizedCard;
}

export class fluidData {
    value:      string;
    descriptor: string="RklEPUNPTU1PTi5BUFBMRS5JTkFQUC5QQVlNRU5U";
    encoding:   string="Base64";
}

export class tokenizedCard {
    type:            string="001";
    transactionType: string="1";
}

export class processingInformation {
    paymentSolution: string="001";
}
