
export const environment = {

  production: true,

  cybersouceMerchantId: "ni_200200007011_aed",
  RunEnvironment: "apitest.cybersource.com",
  MerchantKeyId: "093133db47e83a37895926dcfa773960",
  sharedSecreatKey: "0d61a626ab114319aba19417b063632a8118580b4c9642e5bfd065dd387f9dfb091d3f5cdf0645c58f2ea13fff2c6e36362f5516fb8e403f844518a2a1f7de6ae4994e292bda4db1be92a559ce9a3b5a835096c1141844eab2cea45e6048ed2a532e2afb334547de86c34cd91acadc6e47c3ecfd0fdd43599fdf6f4a0d2590de",
  CybersourceURL: 'https://apitest.cybersource.com/pts/v2/payments',

  
};
